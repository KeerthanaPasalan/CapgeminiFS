package Amazon_Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Search_Item_StepDefinition 
{
	WebDriver Driver;
	
	@Given("^the user is on the amazon home page$")
	public void the_user_is_on_the_amazon_home_page(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\chromedriver.exe");
        Driver = new ChromeDriver();
        Driver.get("https://www.amazon.in/");	  
	}

	@Then("^select the category as Books$")
	public void select_the_category_as_Books(){
		WebElement Ele = Driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
        Select Select_Category = new Select(Ele);
        Select_Category.selectByIndex(11);	   
	}

	@Then("^enter Da Vinci code in the search text$")
	public void enter_Da_Vinci_code_in_the_search_text() throws Throwable {
		String Search_term = "Da Vinci Code";
        Driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Search_term);	    
	}

	@Then("^click on magnifier button$")
	public void click_on_magnifier_button() throws Throwable {
        Driver.findElement(By.xpath("//input[@tabindex = '10']")).click();	    
	}

	@Then("^get the title of the books and print$")
	public void get_the_title_of_the_books_and_print(){
		List<WebElement> Titles = Driver.findElements(By.xpath("//span[@class = 'a-size-medium a-color-base a-text-normal']"));
        
        for(WebElement ttl : Titles) {
            System.out.println(ttl.getText());
        }
        
        Driver.close();
    }

 }
 
