package Amazon_Test;
 

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(


    features= {"C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing Samples\\Sample\\src\\test\\resources\\Amazon.feature"},
    glue= {"Amazon_Test"},
    dryRun = false,
    strict = false,
    monochrome= true,
    format = {"pretty" , "html:test-output"}

)
 
public class Amazon_TestRunner {
}
