$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/kp32/Desktop/New folder/JAVA/Testing Samples/Sample/src/test/resources/Amazon.feature");
formatter.feature({
  "line": 1,
  "name": "validating the Amazon site",
  "description": "",
  "id": "validating-the-amazon-site",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Search an item and get the title",
  "description": "",
  "id": "validating-the-amazon-site;search-an-item-and-get-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the user is on the amazon home page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "select the category as Books",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "enter Da Vinci code in the search text",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "click on magnifier button",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "get the title of the books and print",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_StepDefinition.the_user_is_on_the_amazon_home_page()"
});
formatter.result({
  "duration": 29229398000,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.select_the_category_as_Books()"
});
formatter.result({
  "duration": 429186700,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.enter_Da_Vinci_code_in_the_search_text()"
});
formatter.result({
  "duration": 196629500,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.click_on_magnifier_button()"
});
formatter.result({
  "duration": 8890101600,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.get_the_title_of_the_books_and_print()"
});
formatter.result({
  "duration": 2565439300,
  "status": "passed"
});
});