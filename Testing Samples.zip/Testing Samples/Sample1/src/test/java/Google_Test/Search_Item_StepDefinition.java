package Google_Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Search_Item_StepDefinition {
	WebDriver Driver;
	@Given("^the user is on the google page$")
	public void the_user_is_on_the_google_page(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\chromedriver.exe");
        Driver = new ChromeDriver();
        Driver.get("https://www.google.in/");	
	}

	@Then("^Search for keyword as Automation Testing$")
	public void search_for_keyword_as_Automation_Testing()  throws Throwable {
		       String name="Automation Testing";
		       Driver.findElement(By.name("q")).sendKeys(name);
	}

	@Then("^Click on Search button$")
	public void click_on_Search_button() throws Throwable {
        Driver.findElement(By.className("gNO89b")).submit();	}

	@Then("^Get the title should be same as search term$")
	public void get_the_title_should_be_same_as_search_term()  throws Throwable {
		List<WebElement> list=Driver.findElements(By.className("LC20lb"));
		for(WebElement o:list) {
		    System.out.println(o.getText());
		}   
		Driver.close();
		}


}
