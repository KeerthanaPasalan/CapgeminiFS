$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/kp32/Desktop/New folder/JAVA/Testing Samples/Sample1/src/test/resources/Google.feature");
formatter.feature({
  "line": 1,
  "name": "validating the Google site",
  "description": "",
  "id": "validating-the-google-site",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Search an item and get the title",
  "description": "",
  "id": "validating-the-google-site;search-an-item-and-get-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the user is on the google page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Search for keyword as Automation Testing",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "Click on Search button",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Get the title should be same as search term",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_StepDefinition.the_user_is_on_the_google_page()"
});
formatter.result({
  "duration": 10307989000,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.search_for_keyword_as_Automation_Testing()"
});
formatter.result({
  "duration": 191015900,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.click_on_Search_button()"
});
formatter.result({
  "duration": 4297993300,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_StepDefinition.get_the_title_should_be_same_as_search_term()"
});
formatter.result({
  "duration": 1321782600,
  "status": "passed"
});
});