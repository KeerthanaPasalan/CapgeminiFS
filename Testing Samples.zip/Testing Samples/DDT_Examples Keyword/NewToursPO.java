package PageObjects;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class NewToursPO {
	WebDriver Driver;
	
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement UName_Txt;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement Pwd_Txt;
	
	@FindBy(name="login")
	@CacheLookup
	WebElement SignIn_Btn;

	@FindBy(name="passCount")
	@CacheLookup
	WebElement Pass_Count;
	
	@FindBy(name="fromPort")
	@CacheLookup
	WebElement Depart_Loc;
	
	@FindBy(name="toPort")
	@CacheLookup
	WebElement Arrival_Loc;
	
	@FindBy(name="findFlights")
	@CacheLookup
	WebElement Cont_Booking;
	
	public WebElement getDepart_Loc() {
		return Depart_Loc;
	}



	public WebElement getCont_Booking() {
		return Cont_Booking;
	}



	public void setCont_Booking() {
		Cont_Booking.click();
	}



	public void setDepart_Loc(String Departure) {
		Select Depart = new Select(Depart_Loc);
		Depart.selectByVisibleText(Departure);
	}



	public WebElement getArrival_Loc() {
		return Arrival_Loc;
	}



	public void setArrival_Loc(String Arrival) {
		Select Arrive = new Select(Arrival_Loc);
		Arrive.selectByVisibleText(Arrival);
	}



	public WebElement getPass_Count() {
		return Pass_Count;
	}



	public void setPass_Count(String Num) {
		Select Passenger = new Select(Pass_Count);
		Passenger.selectByVisibleText(Num);
	}



	public void setUName_Txt(String Uname) {
		UName_Txt.sendKeys(Uname);
	}

	

	public void setPwd_Txt(String pwd_Txt) {
		Pwd_Txt.sendKeys(pwd_Txt); 
	}


	public void setSignIn_Btn() {
		SignIn_Btn.click();
	}
	
	public String getUName_Txt_Text() {
		return UName_Txt.getText();
	}

	public String getPwd_Txt_Text() {
		return Pwd_Txt.getText();
	}
	public int getUName_Txt_Ht() {
		return UName_Txt.getSize().getHeight();
	}
	public int getUName_Txt_Wdt() {
		return UName_Txt.getSize().getWidth();
	}
	
	public Dimension getPwd_Txt() {
		return Pwd_Txt.getSize(); 
	}
	
	public boolean getSignIn_Btn_enable() {
		return SignIn_Btn.isEnabled(); 
	}
	public NewToursPO(WebDriver Driver) {
		this.Driver = Driver;
		PageFactory.initElements(Driver, this);
	}




	
	
	
	
}
