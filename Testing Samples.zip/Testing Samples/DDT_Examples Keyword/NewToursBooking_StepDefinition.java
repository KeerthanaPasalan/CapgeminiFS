package NewTours_Booking_Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.NewToursPO;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import junit.framework.Assert;

public class NewToursBooking_StepDefinition {
	public WebDriver Driver;
	public NewToursPO NewTours_OR;
	@Before
	public void SetUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jyothilp\\Desktop\\Selenium Training Softwares\\Drivers\\Chrome78\\chromedriver.exe");
		Driver = new ChromeDriver();
		Driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Driver.manage().deleteAllCookies();
		NewTours_OR = new NewToursPO(Driver);
		Driver.get("http://www.newtours.demoaut.com/");
	}
	
	@After
	public void Tear_Down() {
		Driver.quit();
	}
	
	
	@Given("^the user is on login page$")
	public void the_user_is_on_login_page() {
		String ttl = Driver.getTitle();
		Assert.assertEquals("Yes, User is on Login Page", "Welcome: Mercury Tours", ttl);
		
	}

	@Then("^the user enter to \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enter_to_and(String Usname, String Pswd) throws InterruptedException {
		
		NewTours_OR.setUName_Txt(Usname);
		NewTours_OR.setPwd_Txt(Pswd);
		Thread.sleep(2000);
	}

	@Then("^click on sign in button$")
	public void click_on_sign_in_button() {
		NewTours_OR.setSignIn_Btn();
	}

	@Given("^the user is on Flight reservation page$")
	public void the_user_is_on_Flight_reservation_page() {
		String FR_TTL = Driver.getTitle();
		Assert.assertEquals("Yes, User is on FR Page", "Find a Flight: Mercury Tours:", FR_TTL);
		
	}
/*
	@Then("^select the passenger count$")
	public void select_the_passenger_count(DataTable PassCount) throws InterruptedException {
		List<String> P_Num = PassCount.asList(String.class);
		for(String P: P_Num) {
			NewTours_OR.setPass_Count(P);
			Thread.sleep(2000);
		}
		
		
	}*/
	
	@Then("^select the \"([^\"]*)\" count$")
	public void select_the_count(String passenger) {
		NewTours_OR.setPass_Count(passenger);
	}

	@Then("^user to enter \"([^\"]*)\" and \"([^\"]*)\" location$")
	public void user_to_enter_and_location(String Departure, String Arrival) throws InterruptedException {
		NewTours_OR.setDepart_Loc(Departure);
		Thread.sleep(2000);
		NewTours_OR.setArrival_Loc(Arrival);
		Thread.sleep(2000);
		
	}

	@Then("^click on continue booking$")
	public void click_on_continue_booking() {
		NewTours_OR.setCont_Booking();
	}
	
}
