package NewTours_BookAFlight_Test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\jyothilp\\Desktop\\All Docs\\QA Training\\BDD_Framework\\BDD_CuCumber_Selenium\\src\\test\\resources\\Features\\NewTours_BookAFlight.feature"},
		glue= {"NewTours_BookAFlight_Test"},
		dryRun = false,
		strict = true,
		monochrome = true,
		format = {"pretty", "html:test-output"}
		
		)

public class BookAFlight_TestRunner {
	
	
}
