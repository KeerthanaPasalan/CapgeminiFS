package NewTours_BookAFlight_Test;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjects.NewToursPO;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import junit.framework.Assert;

public class BookAFlight_StepDefinition {
	public WebDriver Driver;
	public NewToursPO Newtours;
	
	@Before
	public void Startup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jyothilp\\Desktop\\Selenium Training Softwares\\Drivers\\Chrome78\\chromedriver.exe");
		Driver = new ChromeDriver();
		Newtours = new NewToursPO(Driver);
	}
	
	@After
	public void EndUp() {
		Driver.close();
	}
	
	@Given("^the user is on login page$")
	public void the_user_is_on_login_page() {
		Driver.get("http://www.newtours.demoaut.com/");
	}

	@Then("^the user enter mercury as \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enter_mercury_as_and(String UserName, String Password) {
		Newtours.setUName_Txt(UserName);
		Newtours.setPwd_Txt(Password);
	}

	@Then("^click on sign in button$")
	public void click_on_sign_in_button() {
		Newtours.setSignIn_Btn();
	}

	@Given("^the user is on Flight reservation page$")
	public void the_user_is_on_Flight_reservation_page() {
		String ttl = Driver.getTitle();
		Assert.assertEquals("User is on Flight Reservation Page", ttl, ttl);
	}

	@Then("^select the passenger count$")
	public void select_the_passenger_count(DataTable PassCount) {
		List<String> count = PassCount.asList(String.class);
		for(String c: count) {
			Newtours.setPass_Count(c);
		
		}
		
		
		
	}

	@Then("^user to enter \"([^\"]*)\" and \"([^\"]*)\" location$")
	public void user_to_enter_and_location(String Departure, String Arrival)throws InterruptedException {
		Newtours.setDepart_Loc(Departure);
		Newtours.setArrival_Loc(Arrival);
		Thread.sleep(2000);
	}
	@Then("^click on continue booking$")
	public void click_on_continue_booking() {
		Newtours.setCont_Booking();
		
	}
	
	
}
