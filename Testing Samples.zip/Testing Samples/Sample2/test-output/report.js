$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/kp32/Desktop/New folder/JAVA/Testing Samples/Sample2/src/test/resources/NewToursBooking.feature");
formatter.feature({
  "line": 1,
  "name": "validate the newtour application to book a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 8,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on Flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"\u003cDeparture\u003e\" and \"\u003cArrival\u003e\" loaction",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.examples({
  "line": 19,
  "name": "",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;",
  "rows": [
    {
      "cells": [
        "Departure",
        "Arrival"
      ],
      "line": 20,
      "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;1"
    },
    {
      "cells": [
        "London",
        "Paris"
      ],
      "line": 21,
      "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;2"
    },
    {
      "cells": [
        "Paris",
        "London"
      ],
      "line": 22,
      "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;3"
    },
    {
      "cells": [
        "New York",
        "Paris"
      ],
      "line": 23,
      "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;4"
    },
    {
      "cells": [
        "New York",
        "London"
      ],
      "line": 24,
      "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 3,
  "name": "The user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 21,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on Flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"London\" and \"Paris\" loaction",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "The user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 22,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on Flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"Paris\" and \"London\" loaction",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "The user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 23,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on Flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"New York\" and \"Paris\" loaction",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "The user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 24,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-a-flight;enter-the-details-in-for-booking-a-flight;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on Flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"New York\" and \"London\" loaction",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});