$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/kp32/Desktop/New folder/JAVA/Testing Samples/StudentRegistrationPage/src/test/resources/EducationalDetails/educationalDetails.feature");
formatter.feature({
  "line": 1,
  "name": "validate the Educational Details page",
  "description": "",
  "id": "validate-the-educational-details-page",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2102115800,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 1327572100,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "check Title and Text on page",
  "description": "",
  "id": "validate-the-educational-details-page;check-title-and-text-on-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "Checks if the title of the page is \u0027Educational Details\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Check if there is a text \u0027Step 2: Educational Details\u0027",
  "keyword": "And "
});
formatter.match({
  "location": "Education_StepDefenition.checks_if_the_title_of_the_page_is_Educational_Details()"
});
formatter.result({
  "duration": 26378900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 31
    }
  ],
  "location": "Education_StepDefenition.check_if_there_is_a_text_Step_Educational_Details(int)"
});
formatter.result({
  "duration": 55241600,
  "status": "passed"
});
formatter.after({
  "duration": 701134800,
  "status": "passed"
});
formatter.before({
  "duration": 1208713500,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 156923100,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "validate the Graduation",
  "description": "",
  "id": "validate-the-educational-details-page;validate-the-graduation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user doesn\u0027t select Graduation",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "display \u0027Please Select Graduation\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_doesn_t_select_Graduation()"
});
formatter.result({
  "duration": 196646300,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Please_Select_Graduation()"
});
formatter.result({
  "duration": 22047900,
  "status": "passed"
});
formatter.after({
  "duration": 835168000,
  "status": "passed"
});
formatter.before({
  "duration": 1309645800,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 144243600,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "validate the Percentage",
  "description": "",
  "id": "validate-the-educational-details-page;validate-the-percentage",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user doesn\u0027t enter percentage",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Please fill Percentage detail\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_doesn_t_enter_percentage()"
});
formatter.result({
  "duration": 209847100,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Please_fill_Percentage_detail()"
});
formatter.result({
  "duration": 13292100,
  "status": "passed"
});
formatter.after({
  "duration": 734312600,
  "status": "passed"
});
formatter.before({
  "duration": 1318461800,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 133895500,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "validate the Passing Year",
  "description": "",
  "id": "validate-the-educational-details-page;validate-the-passing-year",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user doesn\u0027t enter Passing Year",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display \u0027Please fill Passing Year \u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_doesn_t_enter_Passing_Year()"
});
formatter.result({
  "duration": 279208900,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Please_fill_Passing_Year()"
});
formatter.result({
  "duration": 36042300,
  "status": "passed"
});
formatter.after({
  "duration": 712821200,
  "status": "passed"
});
formatter.before({
  "duration": 1307943200,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 131723800,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "validate the Project Name",
  "description": "",
  "id": "validate-the-educational-details-page;validate-the-project-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user doesn\u0027t enter Project Name",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display \u0027Please fill Project Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_doesn_t_enter_Project_Name()"
});
formatter.result({
  "duration": 376049700,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Please_fill_Project_Name()"
});
formatter.result({
  "duration": 35847300,
  "status": "passed"
});
formatter.after({
  "duration": 707103700,
  "status": "passed"
});
formatter.before({
  "duration": 1282270000,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 162849700,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "validate the Technologies",
  "description": "",
  "id": "validate-the-educational-details-page;validate-the-technologies",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "user doesn\u0027t select Technologies",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "display \u0027Please Select Technologies Used\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_doesn_t_select_Technologies()"
});
formatter.result({
  "duration": 334920700,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Please_Select_Technologies_Used()"
});
formatter.result({
  "duration": 12207900,
  "status": "passed"
});
formatter.after({
  "duration": 691983800,
  "status": "passed"
});
formatter.before({
  "duration": 1276373600,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 110628500,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "validate the Other Technologies",
  "description": "",
  "id": "validate-the-educational-details-page;validate-the-other-technologies",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user doesn\u0027t enter Other Technologies",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "display \u0027Please fill other Technologies Used \u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_doesn_t_enter_Other_Technologies()"
});
formatter.result({
  "duration": 3437459800,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Please_fill_other_Technologies_Used()"
});
formatter.result({
  "duration": 22000,
  "status": "passed"
});
formatter.after({
  "duration": 784881000,
  "status": "passed"
});
formatter.before({
  "duration": 1330733100,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "The user on Educational Details page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "Education_StepDefenition.the_user_is_on_Educational_Details_page()"
});
formatter.result({
  "duration": 203696700,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "succesfully registered",
  "description": "",
  "id": "validate-the-educational-details-page;succesfully-registered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user fills all information",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "display \u0027Your Registration Has succesfully done Plz check you registerd email for account activation link !!!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Education_StepDefenition.user_fills_all_information()"
});
formatter.result({
  "duration": 3417768700,
  "status": "passed"
});
formatter.match({
  "location": "Education_StepDefenition.display_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link()"
});
formatter.result({
  "duration": 4781100,
  "status": "passed"
});
formatter.after({
  "duration": 823842700,
  "status": "passed"
});
});