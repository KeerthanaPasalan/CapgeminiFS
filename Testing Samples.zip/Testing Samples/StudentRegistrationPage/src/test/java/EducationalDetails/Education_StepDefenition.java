package EducationalDetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.EducationalPageFactory;

public class Education_StepDefenition {
	private WebDriver driver;
	EducationalPageFactory educationalPageFactory;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@After 
	public void quitMethod()
	{
		driver.quit();
	}
	
	@Given("^the user is on Educational Details page$")
	public void the_user_is_on_Educational_Details_page() throws Throwable {
		  driver.get("C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\WebPages Set B\\EducationalDetails.html");
		  educationalPageFactory = new EducationalPageFactory(driver);
	}

	@Then("^Checks if the title of the page is 'Educational Details'$")
	public void checks_if_the_title_of_the_page_is_Educational_Details() throws Throwable {
		String title=driver.getTitle();
		Assert.assertEquals("Educational Details", title);
	}

	@Then("^Check if there is a text 'Step (\\d+): Educational Details'$")
	public void check_if_there_is_a_text_Step_Educational_Details(int arg1) throws Throwable {
		String heading=driver.findElement(By.xpath("//h4[@style='font-family: Calibri;']")).getText();
		Assert.assertEquals("Step 2: Educational Details", heading);
	}
	
	@When("^user doesn't select Graduation$")
	public void user_doesn_t_select_Graduation() throws Throwable {
	    educationalPageFactory.setGraduation("");
	    educationalPageFactory.setRegisterBtn();
	}

	@Then("^display 'Please Select Graduation'$")
	public void display_Please_Select_Graduation() throws Throwable {
		String expectedRes = "Please Select Graduation";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@When("^user doesn't enter percentage$")
	public void user_doesn_t_enter_percentage() throws Throwable {
	    educationalPageFactory.setGraduation("BE");
		educationalPageFactory.setPercent("");
		educationalPageFactory.setRegisterBtn();
	}
	
	@Then("^display 'Please fill Percentage detail'$")
	public void display_Please_fill_Percentage_detail() throws Throwable {
		String expectedRes = "Please fill Percentage detail";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}
	

	@When("^user doesn't enter Passing Year$")
	public void user_doesn_t_enter_Passing_Year() throws Throwable {
		educationalPageFactory.setGraduation("BE");
		educationalPageFactory.setPercent("90");
		educationalPageFactory.setPassYear("");
		educationalPageFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill Passing Year '$")
	public void display_Please_fill_Passing_Year() throws Throwable {
		String expectedRes = "Please fill Passing Year";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@When("^user doesn't enter Project Name$")
	public void user_doesn_t_enter_Project_Name() throws Throwable {
		educationalPageFactory.setGraduation("BE");
		educationalPageFactory.setPercent("90");
		educationalPageFactory.setPassYear("2019");
		educationalPageFactory.setProjectName("");
		educationalPageFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill Project Name'$")
	public void display_Please_fill_Project_Name() throws Throwable {
		String expectedRes = "Please fill Project Name";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@When("^user doesn't select Technologies$")
	public void user_doesn_t_select_Technologies() throws Throwable {
		educationalPageFactory.setGraduation("BE");
		educationalPageFactory.setPercent("90");
		educationalPageFactory.setPassYear("2019");
		educationalPageFactory.setProjectName("IOT");
		educationalPageFactory.setRegisterBtn();
	}

	@Then("^display 'Please Select Technologies Used'$")
	public void display_Please_Select_Technologies_Used() throws Throwable {
		   String tech=driver.switchTo().alert().getText();
		   Assert.assertEquals("Please Select Technologies Used", tech);
		   driver.switchTo().alert().accept();
	}

	@When("^user doesn't enter Other Technologies$")
	public void user_doesn_t_enter_Other_Technologies() throws Throwable {
		educationalPageFactory.setGraduation("BE");
		educationalPageFactory.setPercent("90");
		educationalPageFactory.setPassYear("2019");
		educationalPageFactory.setProjectName("IOT");
		educationalPageFactory.setTech();
		educationalPageFactory.setOtherTech("");
		Thread.sleep(3000);

		educationalPageFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill other Technologies Used '$")
	public void display_Please_fill_other_Technologies_Used() throws Throwable {
		/*String expectedRes = "Please fill other Technologies Used";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();*/
	}

	@When("^user fills all information$")
	public void user_fills_all_information() throws Throwable {
		educationalPageFactory.setGraduation("BE");
		educationalPageFactory.setPercent("90");
		educationalPageFactory.setPassYear("2019");
		educationalPageFactory.setProjectName("IOT");
		//educationalPageFactory.setOtherTech("ll");
		educationalPageFactory.setTechJava();
		Thread.sleep(3000);
		educationalPageFactory.setRegisterBtn();
	}

	@Then("^display 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void display_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
		String result=driver.switchTo().alert().getText();
		  Assert.assertEquals("Your Registration Has succesfully done Plz check you registerd email for account activation link !!!", result);


	}


}
