package RegisterPage;

import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.RegisterPageFactory;

public class RegisterStepDefinition {
	private WebDriver driver;
	private RegisterPageFactory registerPageFactory;
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@After 
	public void quitMethod()
	{
		driver.quit();
	}

	@Given("^the user is on 'Personal Details' page$")
	public void the_user_is_on_Personal_Details_page() throws Throwable {
		  driver.get("C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\WebPages Set B\\PersonalDetails.html");
		   registerPageFactory= new RegisterPageFactory(driver);
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		 /*String expectedMessage="Personal Details";
		 String actualMessage=driver.getTitle();
		 Assert.assertEquals(expectedMessage, actualMessage);
		 driver.close();*/
		// Thread.sleep(2000);
		String title=driver.getTitle();

		   Assert.assertEquals("Personal Details", title);


	}

	@Then("^verify the text 'Step One: Personal Details' on the page$")
	public void verify_the_text_Step_One_Personal_Details_on_the_page() throws Throwable {
		 /*String bodyText = driver.findElement(By.tagName("body")).getText();
		 Assert.assertTrue("Text not found on page", bodyText.contains("Step 1: Personal Details"));
		 driver.close();*/
		 //Thread.sleep(2000);
		 String heading=driver.findElement(By.xpath("//h4[@style='font-family:Calibri;']")).getText();

		  Assert.assertEquals("Step 1: Personal Details", heading);
	}

	@When("^the user clicks the 'Next' without entering first name$")
	public void the_user_clicks_the_Next_without_entering_first_name() throws Throwable {
		registerPageFactory.setFirstName("");
		registerPageFactory.setNextPage();
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		 String expectedRes = "Please fill the First Name";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
		// Thread.sleep(2000);

	}

	@When("^the user clicks the 'Next' without entering last name$")
	public void the_user_clicks_the_Next_without_entering_last_name() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("");
		registerPageFactory.setNextPage();
		// Thread.sleep(2000);

	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		 String expectedRes = "Please fill the Last Name";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
		 //Thread.sleep(2000);

	}

	@When("^the user enters invalid email format$")
	public void the_user_enters_invalid_email_format() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("Keerthu");
		registerPageFactory.setNextPage();
		// Thread.sleep(2000);

	}

	@Then("^display 'Please enter valid Email Id\\.'$")
	public void display_Please_enter_valid_Email_Id() throws Throwable {
		 String expectedRes = "Please enter valid Email Id.";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
		// Thread.sleep(2000);

	}

	@When("^the user clicks the 'Next' without entering contact no$")
	public void the_user_clicks_the_Next_without_entering_contact_no() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("");
		registerPageFactory.setNextPage();
		 //Thread.sleep(2000);

	}

	@Then("^display 'Please fill the Contact No\\.'$")
	public void display_Please_fill_the_Contact_No() throws Throwable {
		 String expectedRes = "Please fill the Contact No.";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
		// Thread.sleep(2000);

	}

	@When("^the user enters invalid contact no$")
	public void the_user_enters_invalid_contact_no() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("576");
		registerPageFactory.setNextPage();
		// Thread.sleep(2000);

	}

	@Then("^display 'Please enter valid Contact no\\.'$")
	public void display_Please_enter_valid_Contact_no() throws Throwable {
		 String expectedRes = "Please enter valid Contact no.";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
		 //Thread.sleep(2000);

	}

	@When("^the user clicks the 'Next' without entering addrone$")
	public void the_user_clicks_the_Next_without_entering_addrone() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("9585540590");
		registerPageFactory.setAddressLine1("");
		registerPageFactory.setNextPage();
	}

	@Then("^display 'Please fill the address line One'$")
	public void display_Please_fill_the_address_line_One() throws Throwable {
		String expectedRes = "Please fill the address line 1";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@When("^the user clicks the 'Next' without entering addrtwo$")
	public void the_user_clicks_the_Next_without_entering_addrtwo() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("9585540590");
		registerPageFactory.setAddressLine1("T-Nagar");
		registerPageFactory.setAddressLine2("");
		registerPageFactory.setNextPage();
	}

	@Then("^display 'Please fill the address line Two'$")
	public void display_Please_fill_the_address_line_Two() throws Throwable {
		String expectedRes = "Please fill the address line 2";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	
	/*@When("^the user clicks the 'Next' without entering addr(\\d+)$")
	public void the_user_clicks_the_Next_without_entering_addr(int arg1) throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("9585540590");
		registerPageFactory.setAddressLine1("");
		registerPageFactory.setNextPage();
	}

	@Then("^display 'Please fill the address line (\\d+)'$")
	public void display_Please_fill_the_address_line(int arg1) throws Throwable {
		 String expectedRes = "Please fill the address line "+(arg1);
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}*/

	@When("^the user clicks the 'Next' without selecting any data in city$")
	public void the_user_clicks_the_Next_without_selecting_any_data_in_city() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("9585540590");
		registerPageFactory.setAddressLine1("T-Nagar");
		registerPageFactory.setAddressLine2("KKK");
		registerPageFactory.setCity("");
		registerPageFactory.setNextPage();
	}

	@Then("^display 'Please select city'$")
	public void display_Please_select_city() throws Throwable {
		String expectedRes = "Please select city";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@When("^the user clicks the 'Next' without selecting any data in state$")
	public void the_user_clicks_the_Next_without_selecting_any_data_in_state() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("9585540590");
		registerPageFactory.setAddressLine1("T-Nagar");
		registerPageFactory.setAddressLine2("KKK");
		registerPageFactory.setCity("Chennai");
		registerPageFactory.setState("");
		registerPageFactory.setNextPage();
	}

	@Then("^display 'Please select state'$")
	public void display_Please_select_state() throws Throwable {
		 String expectedRes = "Please select state";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@When("^the user enters all valid informations$")
	public void the_user_enters_all_valid_informations() throws Throwable {
		registerPageFactory.setFirstName("Keerthana");
		registerPageFactory.setLastName("Pasalan");
		registerPageFactory.setEmail("keerthana@gmail.com");
		registerPageFactory.setPhoneNumber("9585540590");
		registerPageFactory.setAddressLine1("T-Nagar");
		registerPageFactory.setAddressLine2("KKK");
		registerPageFactory.setAddressLine2("");
		registerPageFactory.setCity("Chennai");
		registerPageFactory.setState("Tamilnadu");
		registerPageFactory.setNextPage();
		Thread.sleep(2000);
	}

	@Then("^display 'Personal details are validated and accepted successfully\\.'$")
	public void display_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
		 String expectedRes = "Personal details are validated and accepted successfully.";
		 String actualRes = driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedRes, actualRes);
		 driver.switchTo().alert().accept();
	}

	@Then("^navigated to 'Education Details' page$")
	public void navigated_to_Education_Details_page() throws Throwable {
		driver.get("C:\\Users\\kp32\\Desktop\\New folder\\JAVA\\Testing\\WebPages Set B\\EducationalDetails.html");
		driver.close();
	}


}
