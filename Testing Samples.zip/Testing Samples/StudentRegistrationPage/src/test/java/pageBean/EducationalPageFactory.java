package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationalPageFactory {

WebDriver driver;

@FindBy(name="graduation")
@CacheLookup
WebElement graduation;

@FindBy(id="txtPercentage")
@CacheLookup
WebElement percent;

@FindBy(id="txtPassYear")
@CacheLookup
WebElement passYear;

@FindBy(name="projectName")
@CacheLookup
WebElement projectName;

@FindBy(xpath="//input[@value='Java']")
@CacheLookup
WebElement techJava;

@FindBy(xpath="//input[@value='Other']")
@CacheLookup
WebElement tech;

@FindBy(name="otherTechnologies")
@CacheLookup
WebElement otherTech;

@FindBy(id="btnRegister")
@CacheLookup
WebElement registerBtn;

public WebDriver getDriver() {
	return driver;
}


public void setDriver(WebDriver driver) {
	this.driver = driver;
}

public WebElement getGraduation() {
	return graduation;
}

public void setGraduation(String graduation) {
	this.graduation.sendKeys(graduation);
}

public WebElement getPercent() {
	return percent;
}

public void setPercent(String percent) {
	this.percent.sendKeys(percent);
}

public WebElement getPassYear() {
	return passYear;
}

public void setPassYear(String passYear) {
	this.passYear.sendKeys(passYear);
}

public WebElement getProjectName() {
	return projectName;
}

public void setProjectName(String projectName) {
	this.projectName.sendKeys(projectName);
}
public WebElement getTechJava() {
	return techJava;
}


public void setTechJava() {
	this.techJava.click();
}

public WebElement getTech() {
	return tech;
}

public void setTech() {
	this.tech.click();
}

public WebElement getOtherTech() {
	return otherTech;
}

public void setOtherTech(String otherTech) {
	this.otherTech.sendKeys(otherTech);
}

public WebElement getRegisterBtn() {
	return registerBtn;
}

public void setRegisterBtn() {
	this.registerBtn.click();
}

public EducationalPageFactory(WebDriver driver) {
	this.driver = driver;
	PageFactory.initElements(driver, this);
 }

}
