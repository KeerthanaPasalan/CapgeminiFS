package com.capgemini.service;

import java.util.List;
import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;

public interface BankService {
	long insertBankDetails(BankDetails customer);
	//For creating Bank Account
	long retrieveBank(Long account1);
	//For Showing Balance
	long depositMoney(Long account, Long depositAmount);
	//For depositing money in one account
	long withdrawMoney(Long accountNo3, Long withdrawAmount);
	//For withdrawing amount from given account
	long fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount);
	//Transferring amount to another account
	void printTransaction();
	boolean nameValidation(String name);
	//Name validation like (Name starts with caps)
	boolean mobileNumberValidation(long mobileNumber);
	//mobile number validation like(mobile number should be 10 digits)

}
