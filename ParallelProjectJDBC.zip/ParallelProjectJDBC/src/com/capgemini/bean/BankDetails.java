package com.capgemini.bean;

public class BankDetails {
	private String name;
	private String branch;
	private Long balance;
	private String accountType;
	private long mobileNumber;
	private long accountNumber;
	//Generate getters and setters
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	//Generate to Strings

	@Override
	public String toString() {
		return "BankDetails [ name=" + name + ", branch=" + branch + ", balance=" + balance + ", accounttype="
				+ accountType + ", mobilenumber=" + mobileNumber + "]";
	}

}
