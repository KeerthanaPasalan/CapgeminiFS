package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import java.util.HashMap;
//import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.AccountNumberNotFoundException;

public class BankDaoImpl implements BankDao {
	//Using Map getting customer details
	Map<Long, BankDetails> customers = new HashMap<Long, BankDetails>();
	Map<Transaction, Long> tranInfo = new HashMap<Transaction, Long>();

	@Override
	public long insertBankDetails(BankDetails customer) {		
		Connection conn= DBConnect.getConnection();
		long a=0;
		try {
			PreparedStatement stmt= conn.prepareStatement("insert into bank values(seq.nextval,?,?,?,?,?)");
			stmt.setString(1, customer.getName() );
			stmt.setString(2, customer.getBranch());
			stmt.setLong(3, customer.getBalance());
			stmt.setString(4, customer.getAccountType());
			stmt.setLong(5, customer.getMobileNumber());
    		int result=stmt.executeUpdate(); 
    		if(result>0)
    	    {
    	        System.out.println("Registered successfully");
    			PreparedStatement stmt1= conn.prepareStatement("select seq.currval from dual");
    			ResultSet result1=stmt1.executeQuery();
    			result1.next();
    			 a=result1.getLong(1);
    	    }
    	    else
    	    {
    	    	System.out.println("Please enter the valid credentials");
    	    }
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return a;
	}
	@Override
	public long retrieveBank(Long account1) {
		//Retrieving balance from the given account
        long bal=0;
        try {
        	BankDetails b1=customers.get(account1);
    		Connection conn= DBConnect.getConnection();   
            PreparedStatement stmt=conn.prepareStatement("select balance from bank where accountnumber=? ");
            stmt.setLong(1,account1);
            ResultSet res=stmt.executeQuery();
            while(res.next())
            {
                bal=res.getLong(1);
                PreparedStatement stmt1=conn.prepareStatement("select balance from bank where accountnumber=? ");
            }
            if(b1==null)
            {
            	throw new AccountNumberNotFoundException("No Account found with this given account number");
            	}
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
        return bal ;
       
    }

	@Override
	public long depositMoney(Long account2, Long depositAmount) {
		//Depositing amount for the given account 
    	BankDetails b1=customers.get(account2);
    	long bal=0;
    	long amt=0;
        try {
        Connection conn=DBConnect.getConnection();
   
            PreparedStatement stmt=conn.prepareStatement("select balance from bank where accountnumber=? ");
            stmt.setLong(1,account2);
            ResultSet res=stmt.executeQuery();
            while(res.next())
            {
                bal=res.getLong(1);
                amt=bal+depositAmount;
                PreparedStatement stmt1=conn.prepareStatement("update bank set balance=? where accountnumber=?");
                stmt1.setFloat(1, amt);
                stmt1.setLong(2,account2);
                int res1=stmt1.executeUpdate();
            if(res1>0)
            {
                
                PreparedStatement stmt2=conn.prepareStatement("insert into Transaction values(transaction1.nextval,?,?,?,?,?)");
                stmt2.setLong(1, account2);
                stmt2.setLong(2, account2);
                stmt2.setLong(3, bal);
                stmt2.setLong(4, amt);
                stmt2.setString(5, "depo");
                int result1=stmt2.executeUpdate();
                
            }
            else
            {
                System.out.println("no");
            }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return amt;
      
  	}

	@Override
	public long withdrawMoney(Long accountNo3, Long withdrawAmount) {
		BankDetails b1=customers.get(accountNo3);
	        long bal=0;
	        long amt=0;
	       
	        try {
	        Connection conn=DBConnect.getConnection();
	   
	            PreparedStatement stat=conn.prepareStatement("select balance from bank where accountnumber=? ");
	            stat.setLong(1,accountNo3);
	            ResultSet res=stat.executeQuery();
	            while(res.next())
	            {
	                bal=res.getLong(1);
	                amt=bal-withdrawAmount;
	                PreparedStatement stat1=conn.prepareStatement("update bank set balance=? where accountnumber=?");
	                stat1.setFloat(1, amt);
	                stat1.setLong(2,accountNo3);
	                int res1=stat1.executeUpdate();
	                if(res1>0)
	                {
	                    
	                    PreparedStatement stmt1=conn.prepareStatement("insert into Transaction values(transaction1.nextval,?,?,?,?,?)");
	                    stmt1.setLong(1, accountNo3);
	                    stmt1.setLong(2, accountNo3);
	                    stmt1.setLong(3, bal);
	                    stmt1.setLong(4, amt);
	                    stmt1.setString(5, "wdrw");
	                    int result1=stmt1.executeUpdate();
	                    
	                }
	                else
	                {
	                    System.out.println("no");
	                }
	            }
	          
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        return amt;
	    }
	
	@Override
	public long fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount) {
		//Transferring amount from one account to another account
		 long bal=0;
	        long amt=0;
	        long wbal=0;
	        long wamt=0;
			//BankDetails acc1 = customers.get(accountNo1);
	        try {
	        Connection conn=DBConnect.getConnection();
	   
	            PreparedStatement stat=conn.prepareStatement("select balance from bank where accountnumber=? ");
	            stat.setLong(1,accountNo1);
	            ResultSet res=stat.executeQuery();
	            while(res.next())
	            {
	                bal=res.getLong(1);
	                amt=bal-transferAmount;
	                PreparedStatement stat1=conn.prepareStatement("update bank set balance=? where accountnumber=?");
	                stat1.setFloat(1, amt);
	                stat1.setLong(2,accountNo1);
	                int res1=stat1.executeUpdate();
	                
	                if(res1>0)
                    {
	                PreparedStatement st1=conn.prepareStatement("insert into Transaction values(transaction1.nextval,?,?,?,?,?)");
                    st1.setLong(1, accountNo1);
                    st1.setLong(2, accountNo2);
                    st1.setLong(3, bal);
                    st1.setLong(4, res1);
                    st1.setString(5, "tran");
                    int result3=st1.executeUpdate();
                    }
	               
	               
	                PreparedStatement wstat=conn.prepareStatement("select balance from bank where accountnumber=? ");
	                wstat.setLong(1,accountNo2);
	                ResultSet wres=wstat.executeQuery();
	                while(wres.next())
	                {
	                    wbal=wres.getLong(1);
	                    wamt=wbal+transferAmount;
	                    PreparedStatement stat2=conn.prepareStatement("update bank set balance=? where accountnumber=?");
	                    stat2.setFloat(1, wamt);
	                    stat2.setLong(2,accountNo2);
	                    int wres1=stat2.executeUpdate();
	                    if(wres1>0)
	                    {
	                        
	                        PreparedStatement st2=conn.prepareStatement("insert into Transaction values(transaction1.nextval,?,?,?,?,?)");
	                        st2.setLong(1, accountNo1);
	                        st2.setLong(2, accountNo2);
	                        st2.setLong(3, bal);
	                        st2.setLong(4, res1);
	                        st2.setString(5, "tran");
	                        int result4=st2.executeUpdate();
	                        
	                    }
	                }
	             }
	           }catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        return amt;
	    }

	@Override
	public void printTransaction() {
    	//BankDetails b1=new BankDetails();
		Transaction b1=new Transaction();
	        PreparedStatement stmt;
	        try {
		        Connection conn=DBConnect.getConnection();
	             stmt=conn.prepareStatement("select * from Transaction");
	            ResultSet s= stmt.executeQuery();
	            while(s.next())
	            {
	            long transctionId=s.getLong(1);
	            long fromAccount=s.getLong(2);
	            long toAccount=s.getLong(3);
	            long oldBalance=s.getLong(4);
	            long newBalance=s.getLong(5);
	            String transactionType=s.getString(6);
	            b1.setTransctionId(transctionId);
	            b1.setFromAccount(fromAccount);
	            b1.setToAccount(toAccount);
	            b1.setOldBalance(oldBalance);
	            b1.setNewBalance(newBalance);
	            b1.setTransactionType(transactionType);
	            System.out.println(b1);
	        
	            }
	        } 
	        
	        catch (SQLException e) {
	            
	            e.printStackTrace();
	        }
		
	        
	    }}

