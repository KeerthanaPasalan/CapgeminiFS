package com.cap.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.CustomerManage;


@Repository
public interface CustomerManageRepo extends JpaRepository<CustomerManage,Long > {

	
	@Query(value="select * from capstore_customer where customer_Status like 'active'",nativeQuery = true)
	public List<CustomerManage> viewActiveCustomer();
	
	@Query(value="select * from capstore_customer where customer_Status like 'inactive'",nativeQuery = true)
	public List<CustomerManage> viewInActiveCustomer();
}
