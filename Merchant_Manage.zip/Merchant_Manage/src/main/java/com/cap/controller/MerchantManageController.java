package com.cap.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.CustomerManage;
import com.cap.entities.MerchantManage;
import com.cap.entities.ProductManage;
import com.cap.service.MerchantService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value="/manage") //
public class MerchantManageController {
	@Autowired
	MerchantService service;
	
	
	//Merchants manage 
	
//	@PostMapping(value="/addMerchants")
//	public MerchantManage addMerchants(@RequestBody MerchantManage merchantManage) {
//		return service.addMerchants(merchantManage);
//	}
	
	@PostMapping("/addMerchants")
	public MerchantManage addMerchants(@RequestBody MerchantManage merchantManage) {
		return service.addMerchants(merchantManage);
	}
	
	@DeleteMapping(value="/deleteMerchants/{id}")
	public void deleteMerchants(@PathVariable int id) {
		service.deleteMerchants(id);		
	}

	@GetMapping(value="/viewActiveMerchants")
	public List<MerchantManage> viewActiveMerchants() {
		return service.viewActiveMerchants();
	}
	
	@GetMapping(value="/viewInActiveMerchants")
	public List<MerchantManage> viewInActiveMerchants() {
		return service.viewInActiveMerchants();
	}

	@GetMapping(value="/viewMerchantById/{id}")
	public MerchantManage viewMerchantById(@PathVariable int id) {
		return service.viewMerchantById(id);
	}
	
	@GetMapping(value="/activeMerchants/{id}")
	public MerchantManage activeMerchants(@PathVariable int id) {
	
		return service.activeMerchants(id);
		
	}
	
	//product manage 
		
	@GetMapping(value="/viewAllProduct")
	public List<ProductManage> viewAllProducts() {
		
		return service.viewAllProducts();
	}
	
	@GetMapping(value="/viewProductById/{id}")
	public ProductManage viewProductById(@PathVariable long productId) {
   		return service.viewProductById(productId);
	}
	
	//customer manage 
	
	@GetMapping(value="/viewAllCustomer")
	public List<CustomerManage> viewAllcustomers() {
		
	   return service.viewAllCustomers();
		}
	@GetMapping(value="/viewCustomerById/{id}")
	public CustomerManage viewCustomerById(@PathVariable long customer_Id) {
		
		return service.viewCustomerById(customer_Id);
	
	
	}
	@PutMapping(value="/activeCustomers/{id}")
	public CustomerManage activeCustomers(long id) 
	{
		return service.activeCustomers(id);
		
	}
	@GetMapping(value="/viewActiveCustomer")
	public List<CustomerManage> viewActiveCustomer(){
		return service.viewActiveCustomer();
		
	}
	@GetMapping(value="/viewInActiveCustomer")
	public List<CustomerManage> viewInActiveCustomer() {
		return service.viewInActiveCustomer();
	}
	
	
	}

