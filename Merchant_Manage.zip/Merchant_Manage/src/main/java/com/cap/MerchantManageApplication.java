package com.cap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantManageApplication.class, args);
	}

}
