package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="capstore_merchants")
public class MerchantManage {
	
	 @Id
     @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq_gen")
     @SequenceGenerator(name = "merchant_seq_gen", initialValue = 10000, sequenceName = "merchant_seq_gen")
     @Column(length=10)
     private int merchantId;
	 @Column (length=15)
	 private String userName;
	 @Column (length=20)
	 private String email;
	 @Column (length=10)
	 private String password;
	 @Column (length=10)
	 private String companyName;
	 @Column (length=10)
	 private String mobNo;
     @Column (length=20)
	 private String address;
	 @Column (length=12)
	 private String aadharNo;
	 @Column (length=8)
	 private String merchant_status="inactive";
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getMerchant_status() {
		return merchant_status;
	}
	public void setMerchant_status(String merchant_status) {
		this.merchant_status = merchant_status;
	}
	
	public MerchantManage(int merchantId, String userName, String email, String password, String companyName,
			String mobNo, String address, String aadharNo, String merchant_status) {
		super();
		this.merchantId = merchantId;
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.companyName = companyName;
		this.mobNo = mobNo;
		this.address = address;
		this.aadharNo = aadharNo;
		this.merchant_status = merchant_status;
	}
	public MerchantManage() {
		super();
	}
	
	
	 
	 
	 
}
