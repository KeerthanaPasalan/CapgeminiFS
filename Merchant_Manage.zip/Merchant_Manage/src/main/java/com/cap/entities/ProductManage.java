package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="capstore_products123")
public class ProductManage {
	    @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq_gen")
	    @SequenceGenerator(name = "product_seq_gen", initialValue = 1000, sequenceName = "product_seq")
	    private long productId;
	    @Column(length = 20)
	    private String productType;
	    @Column(length = 50)
	    private String productName;
	    @Column(length = 10)
	    private double productPrice;
	    @Column(length = 100)
	    private String productDescription;
	    @Column(length = 100)
	    private int productAvailability;
	    
//	    @ManyToOne 
//	    @JoinColumn(name = "merchant_Id")
//	    private MerchantManage merchant;
	    
	    
	  
		public long getProductId() {
			return productId;
		}
//		public MerchantManage getMerchant() {
//			return merchant;
//		}
//		public void setMerchant(MerchantManage merchant) {
//			this.merchant = merchant;
//		}
		public void setProductId(long productId) {
			this.productId = productId;
		}
		public String getProductType() {
			return productType;
		}
		public void setProductType(String productType) {
			this.productType = productType;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public double getProductPrice() {
			return productPrice;
		}
		public void setProductPrice(double productPrice) {
			this.productPrice = productPrice;
		}
		public String getProductDescription() {
			return productDescription;
		}
		public void setProductDescription(String productDescription) {
			this.productDescription = productDescription;
		}
		public int getProductAvailability() {
			return productAvailability;
		}
		public void setProductAvailability(int productAvailability) {
			this.productAvailability = productAvailability;
		}
		public ProductManage(long productId, String productType, String productName, double productPrice,
				String productDescription, int productAvailability,MerchantManage merchant) {
			super();
			this.productId = productId;
			this.productType = productType;
			this.productName = productName;
			this.productPrice = productPrice;
			this.productDescription = productDescription;
			this.productAvailability = productAvailability;
			//this.merchant=merchant;
			
			
		}
		public ProductManage() {
			super();
		}
		
		
	    
	    

}
