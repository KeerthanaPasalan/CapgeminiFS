package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.entity.Insurance;



public interface InsuranceService {
	List<Insurance> addInsurance(Insurance insurance);
	public List<Insurance> updateInsurance(int id,Insurance insurance);
	public void deleteInsurance(int eid);
   
	public double calculateInsuranceAmount(double price,int year);
	public Optional<Insurance> viewInsuranceById(Integer id);
	public List<Insurance> viewAllInsurance();
	
	
}
