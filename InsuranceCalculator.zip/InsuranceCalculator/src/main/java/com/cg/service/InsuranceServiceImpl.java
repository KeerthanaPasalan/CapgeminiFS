package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.InsuranceDao;
import com.cg.entity.Insurance;

@Service
public class InsuranceServiceImpl implements InsuranceService{
	


	@Autowired
	InsuranceDao insuranceDao;
	
	@Override
	public List<Insurance> addInsurance(Insurance insurance) {
		// TODO Auto-generated method stub
		insuranceDao.save(insurance);
		return insuranceDao.findAll();
	}

	@Override
	public List<Insurance> updateInsurance(int id, Insurance insurance) {
		// TODO Auto-generated method stub
		Optional<Insurance> e=insuranceDao.findById( id);
		Insurance e1=e.get();
		
		//e1.setId(insurance.getId());
		e1.setInsuranceAmount(insurance.getInsuranceAmount());
		e1.setOnRoadPrice(insurance.getOnRoadPrice());
		e1.setPurchaseYear(insurance.getPurchaseYear());
		e1.setVehicleModel(insurance.getVehicleModel());
		e1.setExpDate(insurance.getExpDate());
		
		insuranceDao.save(e1);
		
		return insuranceDao.findAll();
	}

	@Override
	public void deleteInsurance(int eid) {
		insuranceDao.deleteById(eid);
	}

	@Override
	public Optional<Insurance> viewInsuranceById(Integer id) {
		return insuranceDao.findById(id);
	
	}

	@Override
	public List<Insurance> viewAllInsurance() {
		
		return insuranceDao.findAll();
		
	}

	@Override
	public double calculateInsuranceAmount(double price, int year) {
		int time=2019-year;
		int a=time*5;
		double price1=(price-(price*a/100));
		double i=(price1*2.5/100);
		return i;	
	}  
}
