package com.capgemini.service;

import java.util.List;
import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;

public interface BankService {
	
	void insertBankDetails(BankDetails customer);
	
	BankDetails retrieveBank(Long account1);
	
	long depositMoney(Long account, Long depositAmount);
	
	long withdrawMoney(Long accountNo3, Long withdrawAmount);
	
	long fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount);
	
	void ListCustomers();
	
	boolean nameValidation(String name);
	
	boolean mobileNumberValidation(long mobileNumber);

	List<Transaction> printTransaction();


}
