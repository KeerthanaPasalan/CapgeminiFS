import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int eid;
	private String ename;
	private int esal;
	
	private Address add;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public Address getAdd() {
		return add;
	}
	
	public void setAdd(Address add) {
		this.add = add;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", add=" + add + "]";
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Autowired
	public Employee(int eid, String ename, int esal, Address add) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		this.add = add;
	}
	

	void display()
	{
		System.out.println(this.eid+" "+this.ename+" "+this.esal+" "+this.add);
	}
	
}
