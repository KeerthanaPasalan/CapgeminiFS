import org.springframework.beans.factory.annotation.Autowired;

public class Person {
private int pid;
private String pname;
private int page;
private Address add;
private TAddress add1;

public TAddress getAdd1() {
	return add1;
}
@Autowired
public void setAdd1(TAddress add1) {
	this.add1 = add1;
}
public Address getAdd() {
	return add;
}
@Autowired
public void setAdd(Address add) {
	this.add = add;
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPage() {
	return page;
}
public void setPage(int page) {
	this.page = page;
}
void display()
{
	System.out.println(this.pid+" "+this.pname+" "+this.page+" "+this.add+" "+this.add1);
}
}
