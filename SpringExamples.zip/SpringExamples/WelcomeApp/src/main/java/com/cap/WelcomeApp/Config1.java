package com.cap.WelcomeApp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config1 {
	@Bean("getEmp")
	public Employee getEmployee()
	{
		return new Employee();
	}
}


