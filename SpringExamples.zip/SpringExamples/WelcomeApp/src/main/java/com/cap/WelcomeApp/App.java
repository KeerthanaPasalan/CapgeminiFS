package com.cap.WelcomeApp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context= new AnnotationConfigApplicationContext("Config1.java");
    	Object ob = context.getBean("getEmp", Employee.class);
    	Employee e=(Employee)ob;	
    	//e.getEid(123);
    	e.display();
    }
}
