import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Employee {
private int eid;
private String ename;
private int esal;
private Map<String, String> address;

public Map<String, String> getAddress() {
	return address;
}
public void setAddress(Map<String, String> address) {
	this.address = address;
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getEsal() {
	return esal;
}
public void setEsal(int esal) {
	this.esal = esal;
}   

public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
void display()
{
	System.out.println("Address");
	System.out.println(this.eid+" "+this.ename+" "+this.esal);
	
	//Set<Entry<String,String>> set=
	Iterator<Map.Entry<String, String>> itr = address.entrySet().iterator();
	   
    while(itr.hasNext())
    {
         Map.Entry<String, String> entry = itr.next();
         System.out.println("Key = " + entry.getKey() +
                             ", Value = " + entry.getValue());
    }
}
}
