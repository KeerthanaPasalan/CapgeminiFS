package com.capgemini.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;

import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.DBConnect;
import com.capgemini.exception.AccountNumberNotFoundException;
import com.capgemini.service.BankService;
import com.capgemini.service.BankServiceImpl;

public class MainUi {
	static BankService bs = new BankServiceImpl();

	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		while (true) {
			//showing bank options 
			System.out.println("Welcome to OurBAnk");
			System.out.println("1.create Account ");
			System.out.println("2.Retrieveing Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			int option = scanner.nextInt();

			switch (option) {
			case 1:	
				//For AccountCreation
				boolean nameValid= false;		
				String name=null;
				
				do{	
					System.out.println("Enter Your Name: ");
					name=scanner.next();
					nameValid=bs.nameValidation(name);
					if(!nameValid)
					{
						System.out.println("Name must Starts with caps..Enter valid name");
					}
				}
				while(!nameValid);
				boolean numberValid = false;
	            System.out.println("Enter Your Mobile Number");
	            long mobileNo;
	              //mobile number validating
	            do{
	              mobileNo=scanner.nextLong();
	              numberValid=bs.mobileNumberValidation(mobileNo);
	              if(!numberValid)
	              {
	              	System.out.println("Enter valid mobile number... Please Enter only 10 numbers..");
	                System.out.println("Enter Mobile Number: ");
	           	  }
	            }while(!numberValid);
				System.out.println("Enter Your branch ");
				String branch = scanner.next();
				System.out.println("Enter balance: ");
				Long balance = scanner.nextLong();
				System.out.println("Enter your account type: ");
				String accountType = scanner.next();

				BankDetails customer = new BankDetails();
				customer.setName(name);
				customer.setBranch(branch);
				customer.setBalance(balance);
				customer.setAccountType(accountType);
				customer.setMobileNumber(mobileNo);
				System.out.println("Account Created");
				long accno =bs.insertBankDetails(customer);
				System.out.println("Your account number: " + accno);

				break;
			case 2:
				//For showing Balance 
				try{
				System.out.println("Fetching your balance");
				System.out.println("Enter your account number");
				Long accno1 = scanner.nextLong();
				long b1 = bs.retrieveBank(accno1);
				System.out.println("Balance= " + b1);
				System.out.println("**************");
				}
				catch(AccountNumberNotFoundException ae)
				{
					System.out.println(ae.getMessage());
				}
				break;

			case 3:
				//For deposting Amount
				try{	
				System.out.println("Enter your account number");
				Long account2 = scanner.nextLong();
				System.out.println("Enter the Amount to be deposited");
				Long depositAmount = scanner.nextLong();
				long b1 = bs.depositMoney(account2, depositAmount);
				System.out.println("Updated Balance= " + b1);
				System.out.println("*******AMOUNT DEPOSITED SUCCESSFULLY*******");
				System.out.println(b1);
				}
				catch(AccountNumberNotFoundException ae)
				{
					System.out.println(ae.getMessage());
				}
				break;

			case 4:
				//For Withdrawing amount
				try{
				System.out.println("Enter your account number");
				Long accountNo3 = scanner.nextLong();
				System.out.println("Enter the amount to be withdrawn");
				Long withdrawAmount = scanner.nextLong();
				long b1 = bs.withdrawMoney(accountNo3, withdrawAmount);
				System.out.println("Remaining balance" + b1);
				System.out.println("AMOUNT WITHDRAWN SUCCESSFULLY");
				}
				catch(AccountNumberNotFoundException ae)
				{
					System.out.println(ae.getMessage());

				}
				break;

			case 5:
				//For transfer amount from one account to another account
				try
				{
				System.out.println("Enter your account number:");
				Long accountNo1 = scanner.nextLong();
				System.out.println("Enter Payee Account number");
				Long accountNo2 = scanner.nextLong();
				System.out.println("Enter Tranfer Amount:");
				Long transferAmount = scanner.nextLong();
				long b5 = bs.fundTransfer(accountNo1, accountNo2, transferAmount);
				System.out.println("Your cuurent balance is " + b5);
				}
				catch(AccountNumberNotFoundException ae)
				{
					System.out.println("Enter valid Account number");
				}
				break;

			case 6:
			    try {
			    	bs.printTransaction();
                System.out.println("Executed");
                }
                catch (Exception e) {
                    System.out.println("Enter Valid information");
                }
			    break;

			case 7:
				System.out.println("Thank You");
				System.exit(0);
				break;
			}
		}
	}
}
