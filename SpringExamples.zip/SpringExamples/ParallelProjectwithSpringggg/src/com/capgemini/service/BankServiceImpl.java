package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {

	BankDao dao = new BankDaoImpl();

	@Override
	public long insertBankDetails(BankDetails customer) {
		return dao.insertBankDetails(customer);
	}

	@Override
	public long retrieveBank(Long account1) {
		//Retrieving balance from the given account
		return dao.retrieveBank(account1);
	}

	@Override
	public long depositMoney(Long account2, Long depositAmount) {
		//Depositing amount for the given account 
		return dao.depositMoney(account2, depositAmount);
	}

	@Override
	public long withdrawMoney(Long accountNo3, Long withdrawAmount) {
		//withdrawing amount for the given account
		return dao.withdrawMoney(accountNo3, withdrawAmount);

	}

	@Override
	public long fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount) {
		//Transferring amount from one account to another account
		return dao.fundTransfer(accountNo1, accountNo2, transferAmount);
	}

	@Override
	public boolean nameValidation(String name) {
		//Name validation like (Name starts with caps)
		if(name.matches("[A-Z][a-z]*"))
		return true;
		else
		return false;
       }

	@Override
	public boolean mobileNumberValidation(long mobileNumber) {
		//mobile number validation like(mobile number should be 10 digits)
		        String num=Long.toString(mobileNumber);
		        if(num.matches("[6-9][0-9]{9}"))
		            return true;
		        else
		            return false;
		    }

	@Override
	public void printTransaction() {
		dao.printTransaction();
	}

	
}






