
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public class Test {
public static void main(String[] args) {
	Client c= Client.create();
	WebResource res=c.resource("http://localhost:1233/JPA_RS_JERSEY_SERVICE/rest/welcomeService/xyz1?name1=Keerthana&age1=20");
	WebResource res1=c.resource("http://localhost:1233/JPA_RS_JERSEY_SERVICE/rest/welcomeService/xyz/Shrovan/27");
	String res2=res.get(String.class);
	String res3=res1.get(String.class);
	System.out.println(res2);
	System.out.println(res3);
}
}
