package com.cap.SpringAnnotationsDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("empobj")
public class Employee {
private int eid;
private String ename;
private int esal;
@Autowired
private Address add;

@Override
public String toString() {
	return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", add=" + add + "]";
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Address getAdd() {
	return add;
}
public void setAdd(Address add) {
	this.add = add;
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getEsal() {
	return esal;
}
public void setEsal(int esal) {
	this.esal = esal;
}

public Employee(Address add)
{
	super();
	this.add=add;
}
 public void display()
 {
	 add.setHno(123);
	 add.setCity("Trichy");
	 add.setColony("Nagar");
	 System.out.println(eid+" "+ename+" "+esal+" "+add);
 }
}
