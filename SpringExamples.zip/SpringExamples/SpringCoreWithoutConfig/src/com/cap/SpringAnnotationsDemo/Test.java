package com.cap.SpringAnnotationsDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
public static void main(String[] args) {
	ApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
	Employee ob = (Employee) context.getBean("empobj");
	ob.setEid(111);
	ob.setEname("Keerthi");
	ob.setEsal(20000);
ob.display();
}
}
