
public class Student {
private int studid;
private String studname;
private int studmarks;

public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(int studid, String studname, int studmarks) {
	super();
	this.studid = studid;
	this.studname = studname;
	this.studmarks = studmarks;
}
public int getStudid() {
	return studid;
}
public void setStudid(int studid) {
	this.studid = studid;
}
public String getStudname() {
	return studname;
}
public void setStudname(String studname) {
	this.studname = studname;
}
public int getStudmarks() {
	return studmarks;
}
public void setStudmarks(int studmarks) {
	this.studmarks = studmarks;
}
void display()
{
	System.out.println(this.studid+" "+this.studname+" "+this.studmarks);
}

}
