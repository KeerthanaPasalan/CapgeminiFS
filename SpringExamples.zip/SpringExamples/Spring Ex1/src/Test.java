import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
public static void main(String[] args) {
	Resource resource=new ClassPathResource("app.xml");
	BeanFactory factory= new XmlBeanFactory(resource);
	Student st=(Student) factory.getBean("s");
	Student st1=(Student) factory.getBean("s1");
	st.display();
	st1.display();
	
}
}
