package com.pdw.jersey.employee.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.api.json.JSONConfiguration;
public class Test {
	
	public static void main(String[] args) {
		
		ClientConfig cc=new DefaultClientConfig();
		cc.getFeatures().
		put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
		
		Client c=Client.create(cc);
		c.addFilter(new HTTPBasicAuthFilter("pdw","pdw"));
		
		WebResource res=c.resource("http://localhost:8000/CRUDusingJersey/rest/employeeService/getEmployeeById?eid=3");
		
		Employee ee=res.accept("application/json").get(Employee.class);
		
		System.out.println(ee.getEid());
		System.out.println(ee.getName());
		System.out.println(ee.getSalary());
	}

}
