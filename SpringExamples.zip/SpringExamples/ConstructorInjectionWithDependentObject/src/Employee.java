
public class Employee {
	private int eid;
	private String ename;
	private int esal;
	private Address add;
	private TAddress add1;
	
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + ", add=" + add + ", add1=" + add1 + "]";
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int eid, String ename, int esal, Address add, TAddress add1) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		this.add = add;
		this.add1 = add1;
	}
	

	void display()
	{
		System.out.println(this.eid+" "+this.ename+" "+this.esal+" "+this.add+" "+this.add1);
	}
	
}
