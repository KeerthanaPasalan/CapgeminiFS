
public class TAddress {
	private int hno;
	private String colony;
	private String city;
	
	@Override
	public String toString() {
		return "\nTAddress [hno=" + hno + ", colony=" + colony + ", city=" + city + "]";
	}

	public TAddress() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TAddress(int hno, String colony, String city) {
		super();
		this.hno = hno;
		this.colony = colony;
		this.city = city;
	}

}
