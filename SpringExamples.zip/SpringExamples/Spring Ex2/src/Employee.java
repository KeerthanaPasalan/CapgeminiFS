
public class Employee {
private int eid;
private String ename;
private int esal;
private Address add;
private TAddress add1;

public TAddress getAdd1() {
	return add1;
}
public void setAdd1(TAddress add1) {
	this.add1 = add1;
}
public Address getAdd() {
	return add;
}
public void setAdd(Address add) {
	this.add = add;
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getEsal() {
	return esal;
}
public void setEsal(int esal) {
	this.esal = esal;
}   

void display()
{
	System.out.println(this.eid+" "+this.ename+" "+this.esal+" "+this.add+" "+this.add1);
}
}
