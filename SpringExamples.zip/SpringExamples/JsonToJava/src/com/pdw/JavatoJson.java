package com.pdw;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class JavatoJson 
{
	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException 
	{
		Student s=new Student();
		s.setId(1);
		s.setName("sravan");
		s.setMarks(99);
		Address a=new Address();
		a.setFlatno(401);
		a.setArea("lbnagar");
		a.setBuildingName("myhome residency");
		
		s.setAddress(a);
		
		ObjectMapper mapper=new ObjectMapper();
		
		mapper.writeValue(new File("hponline.json"),s);
		System.out.println("json generated");
		
	}

}
