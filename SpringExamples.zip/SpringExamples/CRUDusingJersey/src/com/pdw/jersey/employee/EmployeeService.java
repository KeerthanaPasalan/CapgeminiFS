package com.pdw.jersey.employee;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/employeeService")
public class EmployeeService {

	@GET
	@Path("/getEmployeeById")
	@Produces("application/json")//{eid:123,ename:"sravan",esal:"1234"}
	public Employee getEmployeeById(@QueryParam("eid") int eid)
	{
		Connection con = ConnectionFactory.getConnection();
		Employee emp = null;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from employee where eid='"
					+ eid + "'");
			if (rs.next()) {
				emp = new Employee();
				emp.setEid(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setSalary(rs.getInt(3));
			}} catch (Exception e) {
			System.out.println("Error in EmployeeService getEmployeeById()");
		}
		return emp;
	}
	@POST
	@Path("/createEmployee")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createEmployee(Employee emp) {
		int eid = emp.getEid();
		String name = emp.getName();
		int salary = emp.getSalary();
		Response res = null;
		Connection con = ConnectionFactory.getConnection();
		try {
			PreparedStatement ps = con
					.prepareStatement("insert into Employee values(?,?,?)");
			ps.setInt(1, eid);
			ps.setString(2, name);
			ps.setInt(3, salary);
			int x = ps.executeUpdate();//1
			if (x > 0) {
				res = Response.status(200)
						.entity("Employee inserted successfully").build();
			} else {
				res = Response.status(201).entity("Employee insertion failed")
						.build();
			}
		} catch (Exception e) {
			res = Response.status(202).entity("Employee insertion failed")
					.build();
			System.out.println("Error in EmployeeService createEmployee()");
		}
		return res;	}
	@GET
	@Path("/deleteEmployeeById")
	public Response deleteEmployeeById(@QueryParam("eid") int eid) {
		Response res = null;
		Connection con = ConnectionFactory.getConnection();
		try {
			PreparedStatement ps = con
					.prepareStatement("delete from employee where eid=?");
			ps.setInt(1, eid);
			int x = ps.executeUpdate();
			if (x > 0) {
				res = Response.status(200)
						.entity("Employee deleted successfully...!!!").build();
			} else {
				res = Response.status(201)
						.entity("Employee deletion failed...!!!").build();
			}
		} catch (Exception e) {
			res = Response.status(202).entity("Employee deletion failed...!!!")
					.build();
			System.out.println("Error in EmployeeService deleteEmployeeById()");
		}
		return res;
	}

	@DELETE
	@Path("/delete")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response deleteEmployee(Employee emp) {
		Response res = null;
		int eid = emp.getEid();
		Connection con = ConnectionFactory.getConnection();
		try {

			PreparedStatement ps = con
					.prepareStatement("delete from employee where eid=?");
			ps.setInt(1, eid);
			int x = ps.executeUpdate();
			if (x > 0) {
				res = Response.status(200)
						.entity("Employee deleted successfully...!!!").build();
			} else {
				res = Response.status(201)
						.entity("Employee deletion failed...!!!").build();
			}

		} catch (Exception e) {
			res = Response.status(202).entity("Employee deletion failed...!!!")
					.build();
			System.out.println("Error in EmployeeService deleteEmployeeById()");
		}

		return res;

	}
	@GET
	@Path("/updateEmployeeById")
	@Consumes(MediaType.APPLICATION_JSON)
public Response updateEmployeeById(Employee emp)
{
	Response res=null;
	Connection con = ConnectionFactory.getConnection();
	try
	{
		PreparedStatement ps = con
				.prepareStatement("update employee set salary=?,name=? where eid=?");
		ps.setInt(1,emp.getSalary());
		ps.setString(1,emp.getName());
		ps.setInt(3, emp.getEid());
		int x = ps.executeUpdate();
		if (x > 0) {
			res = Response.status(200)
					.entity("Employee updated successfully...!!!").build();
		} else {
			res = Response.status(201)
					.entity("Employee updation failed...!!!").build();
		}
	}catch(Exception e)
	{
		res = Response.status(202).entity("Employee updation failed...!!!")
				.build();
		System.out.println("Error in EmployeeService update()");
	}
	
	return res;
}
}
