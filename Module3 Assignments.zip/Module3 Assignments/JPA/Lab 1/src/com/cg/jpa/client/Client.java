package com.cg.jpa.client;

import com.cg.jpa.entities.*;
import com.cg.jpa.service.AuthorService;
import com.cg.jpa.service.AuthorServiceImplementation;

public class Client {
	
	public static void main(String[] args){
		
		AuthorService service = new AuthorServiceImplementation();
		
		
		
		
		Author author = new Author();
		author.setAuthorId(100);
		author.setFirstName("Shreyash");
		author.setLastName("Pahade");
		author.setMiddleName("S");
		author.setPhoneNo(7757937887L);
		service.addAuthor(author);
		
		author = service.findAuthorById(100);
		System.out.print("ID:"+author.getAuthorId());
		System.out.println("First Name:"+author.getFirstName());
		System.out.println("Middle Name:"+author.getMiddleName());
		System.out.println("Last Name:"+author.getLastName());
		System.out.println("Phone No:"+author.getPhoneNo());
		
		author.setFirstName("Shreyash M");
		service.updateAuthor(author);
		System.out.println("First Name:"+author.getFirstName());
		
		service.removeAuthor(author);
		System.out.println("End of program...");

		
	}

}
