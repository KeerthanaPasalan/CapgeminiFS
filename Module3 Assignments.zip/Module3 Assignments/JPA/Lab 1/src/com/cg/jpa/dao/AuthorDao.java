package com.cg.jpa.dao;
import com.cg.jpa.entities.*;


public interface AuthorDao {

	public abstract void addAuthor(Author author);

	public abstract void updateAuthor(Author author);

	public abstract void removeAuthor(Author author);

	public abstract Author getAuthorById(int id);
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();
	
}
