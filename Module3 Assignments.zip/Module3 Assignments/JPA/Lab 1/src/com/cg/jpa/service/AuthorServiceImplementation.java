package com.cg.jpa.service;
import javax.persistence.EntityManager;
import com.cg.jpa.entities.*;
import com.cg.jpa.dao.*;

public class AuthorServiceImplementation implements AuthorService {

	private AuthorDao dao;
	
	public AuthorServiceImplementation() {
		dao = new AuthorDaoImplementation();
	}

	
	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.addAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.updateAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public void removeAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.removeAuthor(author);
		dao.commitTransaction();
	}

	@Override
	public Author findAuthorById(int id) {
		// TODO Auto-generated method stub
		Author author = dao.getAuthorById(id);
		return author;
	}
				
		
}
