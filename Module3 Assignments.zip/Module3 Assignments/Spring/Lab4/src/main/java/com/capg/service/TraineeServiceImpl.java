package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Trainee;
import com.capg.dao.TraineeDao;

@Service
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	TraineeDao repository;
	
	@Override
	public void insertTrainee(Trainee trainee) {
		repository.save(trainee);
	}

	@Override
	public void updateTrainee(Trainee trainee) {
		repository.save(trainee);
	}

	@Override
	public Trainee getTrainee(int traineeId) {
		return repository.findById(traineeId).orElse(null);
	}

	@Override
	public List<Trainee> getAllTrainee() {
		return repository.findAll();
	}

	@Override
	public void deleteTrainee(int traineeId) {
		repository.deleteById(traineeId);
	}

}
