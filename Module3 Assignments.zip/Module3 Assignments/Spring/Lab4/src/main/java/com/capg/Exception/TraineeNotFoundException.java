package com.capg.Exception;

public class TraineeNotFoundException extends Exception {

}
