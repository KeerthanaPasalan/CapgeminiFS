insert into trainee values (101,"Suro","Java","Chennai");
insert into trainee values (102,"Zolo","Angular","Pune");
insert into trainee values (103,"Solo","Type Script","Kolkata");