package com.spg;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.spg.DAO.EmployeeDAO;

@SpringBootApplication
public class Application {

	@Autowired
	static
	EmployeeDAO empDao;
	
	public static void main(String[] args) {
		ApplicationContext context =SpringApplication.run(Application.class, args);
		Employee emp1 = context.getBean(Employee.class);
		Employee emp2 = context.getBean(Employee.class);
		EmployeeDAO eDao = context.getBean(EmployeeDAO.class);
		
		List<Employee> list = new ArrayList<Employee>();	
		
		
		emp1.setEmpId(1);
		emp1.setEmpName("Shreyash");
		emp1.setSalaray(90000);
		list.add(emp1);
		emp2.setEmpId(2);
		emp2.setEmpName("Shre");
		emp2.setSalaray(900000);
		
		
		
		list.add(emp2);
		
		System.out.println(list);
		
		eDao.setList(list);
		
		
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Employee ID :   ");
		int id = scan.nextInt();
		eDao.findEmp(id);
		
		
	}

}
