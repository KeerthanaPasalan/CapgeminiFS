package com.spg;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Application.class, args);
		Employee emp1 = context.getBean(Employee.class);
		Employee emp2 = context.getBean(Employee.class);
		SBU sbu = context.getBean(SBU.class);
		
		sbu.setSbuHead("Kiran Rao");
		sbu.setSbuId(1);
		sbu.setSbuName("Product Engineering Services");
		
		emp1.setEmployeeId(12345);
		emp1.setEmployeeName("Harriet");
		emp1.setSalary(40000);
		emp1.setBusinessUnit("PES-BU");
		emp1.setAge(40);
	
		emp2.setEmployeeId(12346);
		emp2.setEmployeeName("Rarriet");
		emp2.setSalary(30000);
		emp2.setBusinessUnit("PES-BU");
		emp2.setAge(30);
		
		List<Employee> list = new ArrayList<Employee>();
		list.add(emp1);
		list.add(emp2);
		
		sbu.setEmpList(list);
		
		System.out.println("SBU Details");
		System.out.println("-------------------------------------------");
		System.out.println(sbu);
		System.out.println("Employee Details:----------------");
		System.out.println(list);
		
		
		
	}

}
