import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

	
public class Example3 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Username: ");
		String uname=sc.next();
		System.out.println("Enter Password");
		String pwd=sc.next();
		System.out.println("Enter your Name");
		String name=sc.next();
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg402" ,"training402" );
		PreparedStatement stmt= conn.prepareStatement("insert into gmail values(?,?.?)");
		stmt.setString(1, uname);
		stmt.setString(2, pwd);
		stmt.setString(3, name);
	    int result=stmt.executeUpdate();
	    if(result>0)
		{
			System.out.println("Login Succes...");
		}
		else
		{
			System.out.println("Enter valid Credentials");
		}
	    
	    conn.close();
}
}
