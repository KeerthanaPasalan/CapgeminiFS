import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Example2 {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
	

	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Username: ");
	String uname=sc.next();
	System.out.println("Enter Password");
	String pwd=sc.next();
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg402" ,"training402" );
	PreparedStatement stmt= conn.prepareStatement("select * from gmail where username=? and password=?");
	stmt.setString(1, uname);
	stmt.setString(2, pwd);
    ResultSet result=stmt.executeQuery();
    if(result.next())
	{
		System.out.println("Login Succes...");
	}
	else
	{
		System.out.println("Enter valid Credentials");
	}
    
    conn.close();
}
}


