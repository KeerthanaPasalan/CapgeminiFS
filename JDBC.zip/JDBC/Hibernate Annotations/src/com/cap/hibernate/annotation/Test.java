package com.cap.hibernate.annotation;

import org.hibernate.Session;

import org.hibernate.Transaction;

public class Test {
	public static void main(String[] args) {
		
		Session session= new org.hibernate.cfg.Configuration().configure().buildSessionFactory().openSession();
		
		Transaction t=session.beginTransaction();
		Employee emp=session.get(Employee.class, 2);
		session.delete(emp);
		t.commit();
		
		/*Transaction t=session.beginTransaction();
		Employee emp=session.get(Employee.class, 2);
		emp.setLastName("Keena");
		session.save(emp);
		t.commit();*/
		
		/*Employee emp=session.get(Employee.class,1);
		System.out.println(emp.getFirstName());*/
		
		/*Transaction t=session.beginTransaction();
		Employee emp= new Employee();
		emp.setId(1005);
		emp.setFirstName("Janani");
		emp.setLastName("Sankar");
		
		session.save(emp);
		t.commit();*/
		
	}
}
