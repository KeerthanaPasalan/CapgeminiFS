import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customers {
	@Id
	@Column(length=5)
private int custId;
	@Column(length=10)
private String custName;

public Customers(int custId, String custName) {
	super();
	this.custId = custId;
	this.custName = custName;
}

public Customers() {
	// TODO Auto-generated constructor stub
}

public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
}
