import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	EntityManagerFactory emfactory= Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager=emfactory.createEntityManager();
	entityManager.getTransaction().begin();
	/*
	Vendor v=new Vendor();
	v.setVendorId(101);
	v.setVendorName("Pradeepa");
	
	Customers c1= new Customers();
	c1.setCustId(501);
	c1.setCustName("Jaanu");
	Customers c2= new Customers();
	c2.setCustId(502);
	c2.setCustName("Nancy");
	
	Set s=new HashSet();
	s.add(c1);
	s.add(c2);
	v.setChildren(s);
	entityManager.persist(v);*/
	
	Vendor ven=entityManager.find(Vendor.class, 101);
	entityManager.remove(ven);
	
	entityManager.getTransaction().commit();
	emfactory.close();
}
}
