package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {

	 private BankDao dao;
	 public BankServiceImpl()
	 {
		 dao=new BankDaoImpl();
	 }

	@Override
	public void insertBankDetails(BankDetails customer) {
		dao.beginTransaction();
		dao.insertBankDetails(customer);
		dao.commitTransaction();		
	}

	@Override
	public BankDetails retrieveBank(Long account1) {
		BankDetails bank=dao.retrieveBank(account1);
		return bank;
	}

	@Override
	public long depositMoney(Long account2, Long depositAmount) {
		dao.beginTransaction();
		long b1= dao.depositMoney(account2, depositAmount);
		dao.commitTransaction();
		return b1;
	}

	@Override
	public long withdrawMoney(Long accountNo3, Long withdrawAmount) {
		dao.beginTransaction();
		long b2= dao.withdrawMoney(accountNo3, withdrawAmount);
		dao.commitTransaction();
		return b2;
	}

	@Override
	public long fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount) {
		dao.beginTransaction();
		long b3= dao.fundTransfer(accountNo1, accountNo2, transferAmount);
		dao.commitTransaction();
		return b3;
	}

	@Override
	public boolean nameValidation(String name) {
		//Name validation like (Name starts with caps)
		if(name.matches("[A-Z][a-z]*"))
		return true;
		else
		return false;
       }

	@Override
	public boolean mobileNumberValidation(long mobileNumber) {
		//mobile number validation like(mobile number should be 10 digits)
		        String num=Long.toString(mobileNumber);
		        if(num.matches("[6-9][0-9]{9}"))
		            return true;
		        else
		            return false;
		    }

	@Override
	public void ListCustomers() {
		dao.beginTransaction();
		dao.ListCustomers();
		dao.commitTransaction();

	}

	@Override
	public List<Transaction> printTransaction() {
		dao.beginTransaction();
		List<Transaction> l1= dao.printTransaction();
		dao.commitTransaction();
		return l1;		
}

}




