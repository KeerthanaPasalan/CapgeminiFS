package com.capgemini.dao;



import org.junit.Test;

import org.junit.Assert;

public class BankDaoImplTest {
	
	BankDao bank= new BankDaoImpl();
	private static final double delta=1e-15;
	
    /*@Test
	public void test() {
		long n=bank.depositMoney(64l, 1000l);
		long ExpectedResult=8000;
		long incorrectResult=2000;
		Assert.assertEquals(ExpectedResult, n, delta);	
		Assert.assertNotEquals(incorrectResult,n,delta);
	}
	*/
	@Test
	public void m1(){
		long n1=bank.withdrawMoney(71l, 2000l);
		long ExpectedResult1=18000;
		long incorrectResult1=2000;
		Assert.assertEquals(ExpectedResult1, n1, delta);
		Assert.assertNotEquals(incorrectResult1,n1,delta);
	}
	
	/*@Test
	public void m2(){
		long n2=bank.fundTransfer(70l, 72l, 1000l);
		long ExpectedResult2=2000;
		long incorrectResult2=2000;
		Assert.assertEquals(ExpectedResult2, n2, delta);	
		Assert.assertNotEquals(incorrectResult2,n2,delta);
	}*/
}
