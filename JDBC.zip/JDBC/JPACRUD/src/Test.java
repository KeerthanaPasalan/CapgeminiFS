import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	EntityManagerFactory emf= Persistence.createEntityManagerFactory("a");
	EntityManager em=emf.createEntityManager();
	//System.out.println(emp.getName());
	
	/*em.getTransaction().begin();
	Employee e= new Employee();
	e.setId(125);
	e.setName("Janai");
	e.setSal(3000);
	em.persist(e);
	em.getTransaction().commit();
	System.out.println("inserted");*/
	//Employee emp=em.find(Employee.class,123);
	//emp.setName("Keerthi");*/
	
	//update
	   
    /*Student s=em.find(Student.class, 12);
    s.setName("Keer"); */
   
   
	Employee emp=em.find(Employee.class,125);
    em.remove(emp);
   
    /*Employee s1=em.find(Student.class, 125);
    em.merge(s1);*/
    /*  Employee e=new Employee();
    e.setId(125);
	e.setName("Janai");
	e.setSal(3000);
	em.persist(e);*/
    //Employee s=em.find(Student.class, 14)
	//System.out.println(emp.getName());
}
}
