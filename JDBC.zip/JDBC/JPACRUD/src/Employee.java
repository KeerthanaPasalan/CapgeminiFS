
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name="Emp")
	public class Employee {
		@Id
		@Column(name="empid",length=10)

	 private int id;
		@Column(name="ename",length=10)
	 private String name;
		@Column(name="esal",length=10)
	 private int sal;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getSal() {
			return sal;
		}
		public void setSal(int sal) {
			this.sal = sal;
		}	
	}


