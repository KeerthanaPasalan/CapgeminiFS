import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp2")
public class Employee {
@Id
@Column(name="EID", length=5)
private int eid;
@Column(name="ENAME", length=10)
private String ename;
@Column(name="ESAL", length=7)
private int esal;

public int getEid() {
	return eid;
}

public void setEid(int eid) {
	this.eid = eid;
}

public String getEname() {
	return ename;
}

public void setEname(String ename) {
	this.ename = ename;
}

public int getEsal() {
	return esal;
}

public void setEsal(int esal) {
	this.esal = esal;
}

}
