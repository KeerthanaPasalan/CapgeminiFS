import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class Test {
public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=emf.createEntityManager();
	em.getTransaction().begin();
/*	Employee e=new Employee(101,"Keerthu",10000);
	Employee e1=new Employee(102,"Kavya",20000);
	Employee e2=new Employee(103,"Pradeepa",30000);
	Employee e3=new Employee(104,"Janu",40000);
	em.persist(e);
	em.persist(e1);
	em.persist(e2);
	em.persist(e3);
    em.getTransaction().commit();*/

	TypedQuery<Employee> q2= em.createQuery("select c from Employee c",Employee.class);
	List<Employee> l1=q2.getResultList();
    for(Employee e4:l1)
    {
        System.out.println(e4.getEid());
        System.out.println(e4.getEname());
    }
    em.getTransaction().commit();
	/*TypedQuery<Employee> q1= em.createQuery("select c from Employee c",Employee.class);
    List<Employee> l=q1.getResultList();
    for(Employee e:l)
    {
        System.out.println(e.getEid());
        System.out.println("\t"+e.getEname());
        System.out.println("\t"+e.getEsal());
        System.out.println();
    }*/
	
	
	/*Query q=em.createQuery("update Employee set esal=25000 where esal<20000");
	q.executeUpdate();
	Query q1 =em.createQuery("delete from Employee where eid=101");
	q1.executeUpdate();
	Query query = em.createQuery("select Max(emp.sal) from Employee emp ");
	int maxsal=(int)query.getSingleResult();
	System.out.println(maxsal);
	em.getTransaction().commit();
	em.close();
	emf.close();*/
}
}

