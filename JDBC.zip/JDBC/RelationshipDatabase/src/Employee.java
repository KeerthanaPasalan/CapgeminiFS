import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue
	@Column(length=10)
private int eid;
	@Column(length=15)
private String ename;
	@Column(length=15)
private String address;
	@Column(length=10)
private int sal;
	@ManyToOne
	@OnDelete(action=OnDeleteAction.CASCADE)
private Department dept;
	public Employee()
	{
		
	}
	public Employee(String ename, String address, int sal, Department dept) {
		super();
		this.ename = ename;
		this.address = address;
		this.sal = sal;
		this.dept = dept;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	
}
