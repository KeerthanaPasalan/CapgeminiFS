import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	EntityManagerFactory emfactory= Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager=emfactory.createEntityManager();
	entityManager.getTransaction().begin();
	//Create departmentEntity
	Department department= new Department();
	department.setDeptname("Developement");
	department.setDeptloc("Chennai");
	//Store Department
	entityManager.persist(department);
	
	Employee e=new Employee("Keerthana","Trichy",12000,department);
	Employee e1=new Employee("Pradeepa","Erode",12000,department);
	Employee e2=new Employee("Janani","Salem",12000,department);
	Employee e3=new Employee("Nancy","Neyveli",12000,department);

	//Store Employees
	entityManager.persist(e);
	entityManager.persist(e1);
	entityManager.persist(e2);
	entityManager.persist(e3);

	entityManager.getTransaction().commit();
}
}
