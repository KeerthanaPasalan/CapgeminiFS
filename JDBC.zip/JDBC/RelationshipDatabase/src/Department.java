import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dept")
public class Department {
	@Id
	@GeneratedValue
	@Column(length=5)
private int deptno;
	@Column(length=15)
private String deptname;
	@Column(length=15)
private String deptloc;
	public Department(String deptname, String deptloc) {
		super();
		this.deptname = deptname;
		this.deptloc = deptloc;
	}
	public Department() {
		// TODO Auto-generated constructor stub
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public String getDeptloc() {
		return deptloc;
	}
	public void setDeptloc(String deptloc) {
		this.deptloc = deptloc;
	}

}
