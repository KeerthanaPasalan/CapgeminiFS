package com.cap.jpacrud.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.jpacrud.dao.EmployeeDao;
import com.cap.jpacrud.dao.EmployeeDaoImpl;
import com.cap.jpacrud.entities.Employee;
@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao dao;
	@Autowired
	public void setEmployeeDao(EmployeeDao dao)
	{
		this.dao=dao;
	}
	
	@Override
	public void addEmployee(Employee employee) {
		dao.addEmployee(employee);
	}

	@Override
	public void updateEmployee(Employee employee) {
		dao.updateEmployee(employee);
	}

	@Override
	public void removeEmployee(int eid) {
		dao.removeEmployee(eid);
	}

	@Override
	public Employee findEmployeeById(int id) {
		Employee employee=dao.getEmployeeById(id);
		return employee;
	}
	@Override
	public void ListAllEmployees() {
		dao.ListAllEmployees();

	}

}
