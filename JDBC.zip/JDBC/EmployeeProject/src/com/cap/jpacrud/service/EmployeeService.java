package com.cap.jpacrud.service;

import com.cap.jpacrud.entities.Employee;

public interface EmployeeService {
	public abstract void addEmployee(Employee employee);

	public abstract void updateEmployee(Employee employee);

	public abstract void removeEmployee(int id3);

	public abstract Employee findEmployeeById(int id);

	public abstract void ListAllEmployees();

}
