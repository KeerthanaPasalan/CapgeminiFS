package com.cap.jpacrud.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.jpacrud.entities.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	public void setEntityManager(EntityManager entityManager) {
	this.entityManager = entityManager;
}
	@Transactional
	public void addEmployee(Employee employee) {
			entityManager.persist(employee);
	}
	
	@Override
	public Employee getEmployeeById(int id) {
		Employee employee= entityManager.find(Employee.class, id);		
		return employee;
	}

	@Transactional
	public void removeEmployee(int eid) {
	Employee employee	=getEmployeeById(eid);
	//	System.out.println(" ***************"+employee.getEmpId());
		
		entityManager.remove(employee);
	}

	@Transactional
	public void updateEmployee(Employee employee) {
		entityManager.merge(employee);
	}

	@Override
	public void ListAllEmployees() {
		TypedQuery<Employee> q2= entityManager.createQuery("select c from Employee c",Employee.class);
		List<Employee> l1=q2.getResultList();
	    for(Employee e:l1)
	    {
	    	System.out.println("\nId:"+e.getEmpId());
	        System.out.println("Name: "+e.getEmpname());
	        System.out.println("Salary: "+e.getEmpsal());
	        System.out.println("Address: "+e.getEmpAddress());
	    }
	   // entityManager.getTransaction().commit();
	}
	
}
