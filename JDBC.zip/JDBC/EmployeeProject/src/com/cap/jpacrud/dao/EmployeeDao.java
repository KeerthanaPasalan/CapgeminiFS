package com.cap.jpacrud.dao;

import com.cap.jpacrud.entities.Employee;

public interface EmployeeDao {
	public abstract Employee getEmployeeById(int id);

	public abstract void addEmployee(Employee employee);

	public abstract void removeEmployee(int eid);

	public abstract void updateEmployee(Employee employee);

	public abstract void ListAllEmployees();

}
