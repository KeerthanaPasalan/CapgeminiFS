package com.cap.jpacrud.client;

import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cap.jpacrud.entities.Employee;
import com.cap.jpacrud.service.EmployeeService;
import com.cap.jpacrud.service.EmployeeServiceImpl;

public class Client {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Bean.xml");
		EmployeeService service = (EmployeeService) ctx.getBean("employeeService");

		Employee employee = new Employee();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Employee Details");
			System.out.println("1.Create Employee Details");
			System.out.println("2.Find Employee by ID");
			System.out.println("3.Update Employee Details");
			System.out.println("4.Remove Employee Details");
			System.out.println("5.List all the Employees");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("To Insert new Employee Details...");
				System.out.println("Enter employee id");
				int id = sc.nextInt();
				employee.setEmpId(id);
				System.out.println("Enter employee name");
				String name = sc.next();
				employee.setEmpname(name);
				System.out.println("Enter employee address");
				String add = sc.next();
				employee.setEmpAddress(add);
				System.out.println("Enter employee salary");
				int sal = sc.nextInt();
				employee.setEmpsal(sal);
				service.addEmployee(employee);
				break;
			case 2:
				System.out.println("To Find the Details by using Id");
				System.out.println("Enter employee id");
				int id1 = sc.nextInt();
				Employee emp1 = service.findEmployeeById(id1);
				if (emp1 != null) {
					System.out.println("Name:" + emp1.getEmpname());
				} else {
					System.out.println("Invalid id");
				}
				System.out.println("Id: " + emp1.getEmpId());
				// System.out.println("Name: "+emp1.getEmpname());
				System.out.println("Address: " + emp1.getEmpAddress());
				System.out.println("Salaray: " + emp1.getEmpsal());
				break;
			case 3:
				System.out.println("Enter employee id for which you need to update");
				System.out.println("Enter the ID ");
				int id2 = sc.nextInt();
				employee = service.findEmployeeById(id2);
				if (employee != null) {
					System.out.println("Enter the name: ");
					String name1 = sc.next();
					employee.setEmpname(name1);
					service.updateEmployee(employee);
				} else {
					System.out.println("Invalid id");
				}
				break;
			case 4:
				System.out.println("Enter employee id to be deleted");
				int id3 = sc.nextInt();
				service.removeEmployee(id3);
				System.out.println(id3+" Record is removed");
				break;
			case 5:
				System.out.println("List all the Employees");
				service.ListAllEmployees();
				break;
			}

		}
	}
}
