package Example1;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="employee2")
public class Employee {
	@Id
	@GeneratedValue
	@Column(length=10)
private int eid;
	@Column(length=15)
private String ename;
	@Column(length=10)
private int sal;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn
private Address add;
	public Employee()
	{
		
	}
	public Employee(String ename, int sal, Address add) {
		super();
		this.ename = ename;
		this.sal = sal;
		this.add = add;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public Address getDept() {
		return add;
	}
	public void setDept(Address add) {
		this.add = add;
	}
	
}
