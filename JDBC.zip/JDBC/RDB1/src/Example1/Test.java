package Example1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	EntityManagerFactory emfactory= Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager=emfactory.createEntityManager();
	entityManager.getTransaction().begin();
	//Create departmentEntity
	Address ad= new Address();
	ad.setAid(1);
	ad.setColony("sff");
	ad.setHno("Sai Apamt");
	ad.setCity("Chennai");
	//Store Department
	entityManager.persist(ad);
	
	Employee e=new Employee("Keerthana",12000,ad);
	Employee e1=new Employee("Pradeepa",12000,ad);
	Employee e2=new Employee("Janani",12000,ad);
	Employee e3=new Employee("Nancy",12000,ad);

	//Store Employees
	entityManager.persist(e);
	entityManager.persist(e1);
	entityManager.persist(e2);
	entityManager.persist(e3);

	entityManager.getTransaction().commit();
	emfactory.close();

}
}

