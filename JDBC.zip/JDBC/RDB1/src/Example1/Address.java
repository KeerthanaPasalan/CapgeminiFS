package Example1;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="add1")
public class Address {
	@Id
	@Column(length=5)
private int aid;
	@Column(length=15)
private String hno;
	@Column(length=15)
private String colony;
	@Column(length=15)
private String city;

public Address(int aid, String hno, String colony, String city) {
	super();
	this.aid = aid;
	this.hno = hno;
	this.colony = colony;
	this.city = city;
}
public Address() {
	// TODO Auto-generated constructor stub
}
public int getAid() {
	return aid;
}
public void setAid(int aid) {
	this.aid = aid;
}
public String getHno() {
	return hno;
}
public void setHno(String hno) {
	this.hno = hno;
}
public String getColony() {
	return colony;
}
public void setColony(String colony) {
	this.colony = colony;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}

