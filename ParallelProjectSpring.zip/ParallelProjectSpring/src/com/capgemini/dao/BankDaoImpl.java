package com.capgemini.dao;

import java.sql.Connection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;


public class BankDaoImpl implements BankDao {
	Transaction t=new Transaction();
	private EntityManager entityManager;
	public BankDaoImpl()
	{
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public void insertBankDetails(BankDetails customer) {
		entityManager.persist(customer);
	}

	@Override
	public BankDetails retrieveBank(Long account1) {
		BankDetails bank= entityManager.find(BankDetails.class, account1);		
		return bank;
	}

	@Override
	public long depositMoney(Long account2, Long depositAmount) {
		
		BankDetails bank=entityManager.find(BankDetails.class, account2);
		long newbal=bank.getBalance();
		long newbal1=depositAmount+newbal;
		bank.setBalance(newbal1);
		entityManager.merge(bank);
		
		t.setFromAccount(account2);
		t.setNewBalance(newbal1);
		t.setOldBalance(newbal);
		t.setToAccount(account2);
		t.setTransactionType("depo");		
		entityManager.persist(t);
		return newbal1;
		
	}

	@Override
	public long withdrawMoney(Long accountNo3, Long withdrawAmount) {
		BankDetails bank=entityManager.find(BankDetails.class, accountNo3);
		long newbal=bank.getBalance();
		long newbal1=newbal-withdrawAmount;
		bank.setBalance(newbal1);
		entityManager.merge(bank);
		
		t.setFromAccount(accountNo3);
		t.setNewBalance(newbal1);
		t.setOldBalance(newbal);
		t.setToAccount(accountNo3);
		t.setTransactionType("wdrw");	
		entityManager.persist(t);
		return newbal1;
	}

	@Override
	public long fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount) {
		BankDetails bank=entityManager.find(BankDetails.class, accountNo1);
		long newbal=bank.getBalance();
		long newbal1=newbal-transferAmount;
		bank.setBalance(newbal1);
		entityManager.merge(bank);
		
		t.setFromAccount(accountNo1);
		t.setNewBalance(newbal1);
		t.setOldBalance(newbal);
		t.setToAccount(accountNo1);
		t.setTransactionType("tran");
		entityManager.persist(t);

		
		BankDetails bank1=entityManager.find(BankDetails.class, accountNo2);
		long newbal2=bank1.getBalance();
		long newbal3=newbal2+transferAmount;
		bank1.setBalance(newbal3);
		entityManager.merge(bank1);
		
		t.setFromAccount(accountNo2);
		t.setNewBalance(newbal3);
		t.setOldBalance(newbal2);
		t.setToAccount(accountNo2);
		t.setTransactionType("tran");
		entityManager.persist(t);
		return newbal1 ;
	}

	@Override
	public void ListCustomers() {
		TypedQuery<BankDetails> q2= entityManager.createQuery("select c from BankDetails c",BankDetails.class);
		List<BankDetails> l1=q2.getResultList();
	    for(BankDetails e:l1)
	    {
	        System.out.print(e.getName());
	        System.out.println(" "+e.getBalance());
	    }
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public List<Transaction> printTransaction() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em=emf.createEntityManager();
		TypedQuery<Transaction> tq=entityManager.createQuery("select c from Transaction c",Transaction.class);
        List<Transaction> list1=tq.getResultList();
        for(Transaction t:list1)
        {
            System.out.println("TransactionID= "+t.getTransctionId()+"  "+"AccountNo= "+t.getFromAccount()+" "+"OldBaalance=  "+t.getOldBalance()+" "+"NewBalanace= "+t.getNewBalance()+" "+"Account2=  "+t.getToAccount()+"  "+"TransactionType=  "+t.getTransactionType());
        }
        return list1;
	}
	
	    }

