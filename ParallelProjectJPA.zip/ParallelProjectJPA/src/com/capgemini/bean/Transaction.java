package com.capgemini.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")
public class Transaction {
	@Id
	@GeneratedValue
	long transctionId;
	long fromAccount;
	long toAccount;
	long oldBalance;
	long newBalance;
	String transactionType;
	//Generate Getters and Setters 
	public long getTransctionId() {
		return transctionId;
	}

	public void setTransctionId(long transctionId) {
		this.transctionId = transctionId;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public long getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(long oldBalance) {
		this.oldBalance = oldBalance;
	}

	public long getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(long newBalance) {
		this.newBalance = newBalance;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	//Generate to String
	@Override
	public String toString() {
		return "Transaction [transctionId=" + transctionId + ", fromAccount=" + fromAccount + ", toAccount=" + toAccount
				+ ", oldBalance=" + oldBalance + ", newBalance=" + newBalance + ", transactionType=" + transactionType
				+ "]";
	}

}
