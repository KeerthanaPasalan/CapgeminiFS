package com.capgemini.exception;

@SuppressWarnings("serial")
public class AccountNumberNotFoundException extends RuntimeException {
	public AccountNumberNotFoundException(String errorMsg) 
	{
      super(errorMsg);
	}
}

