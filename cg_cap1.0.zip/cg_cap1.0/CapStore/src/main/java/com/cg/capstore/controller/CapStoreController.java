package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.CartQuantityProduct;
import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Order;
import com.cg.capstore.entity.OrderQuantityProduct;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.Transaction;
import com.cg.capstore.entity.ViewProduct;
import com.cg.capstore.exception.CapStoreException;
import com.cg.capstore.exception.MerchantException;
import com.cg.capstore.exception.ProductException;
import com.cg.capstore.service.CapStoreService;

@CrossOrigin("*")
@RestController
public class CapStoreController {

	@Autowired
	CapStoreService capStoreService;

	// adminwork########################################################################
	

	@GetMapping(value = "getAllCustomers")
	public List<Customer> getAllCustomer() throws CapStoreException {
		return capStoreService.getAllCustomer();
	}

	@GetMapping(value = "getAllMerchants")
	public List<Merchant> getAllMerchant() throws CapStoreException {
		return capStoreService.getAllMerchant();
	}

	@GetMapping(value = "getAllProducts")
	public List<Product> getAllProducts() throws CapStoreException {
		return capStoreService.getAllProducts();
	}

	@GetMapping(value = "getAllOrders")
	public List<Order> getAllOrders() throws CapStoreException {
		return capStoreService.getAllOrders();
	}

	@GetMapping(value = "manageMerchant/{merchantId}/{flag}")
	public boolean manageMerchant(@PathVariable("merchantId") int merchantId, @PathVariable("flag") boolean flag)
			throws CapStoreException {
		return capStoreService.manageMerchant(merchantId, flag);
	}

	@GetMapping(value = "updateProductStatusByAdmin/{id}/{flag}")
	public boolean updateProductStatusByAdmin(@PathVariable("id") int id, @PathVariable("flag") boolean flag)
			throws CapStoreException {
		return capStoreService.updateProductStatusByAdmin(id, flag);
	}

	@GetMapping(value = "removeMerchant/{id}")
	public boolean removeMerchant(@PathVariable("id") int merchantId) throws CapStoreException {
		return capStoreService.removeMerchant(merchantId);
	}

	@GetMapping(value = "dispatchreportproduct/{id}")
	public List<Integer> getDispatchReport(@PathVariable("id") int productId) throws CapStoreException {
		return capStoreService.getDispatchReport(productId);
	}

	@GetMapping(value = "getallcategory")
	public List<Category> getAllcategory() throws CapStoreException {
		return capStoreService.getAllcategory();
	}

	@GetMapping(value = "dispatchreportcategory/{id}")
	public List<Integer> getDispatchReportCategory(@PathVariable("id") int categoryId) throws CapStoreException {
		return capStoreService.getDispatchReportCategory(categoryId);
	}

	@GetMapping(value = "dispatchreportmerchant/{id}")
	public List<Integer> getDispatchReportMerchant(@PathVariable("id") int merchantId) throws CapStoreException {
		return capStoreService.getDispatchReportMerchant(merchantId);
	}

	@PostMapping(value = "customersignup/{pass}")
	public boolean customerSignUp(@RequestBody Customer customer, @PathVariable("pass") String password)
			throws CapStoreException {
		return capStoreService.customerSignUp(customer, password);
	}

	@PostMapping(value = "merchantsignup/{pass}")
	public boolean merchantSignUp(@RequestBody Merchant merchant, @PathVariable("pass") String password)
			throws CapStoreException {
		return capStoreService.merchantSignUp(merchant, password);
	}

//merchantwork*************************************************************************************************************************************************

	@PostMapping(value = "addproduct", produces = MediaType.TEXT_PLAIN_VALUE)
	public String addProduct(@RequestBody Product product) {
		int productId = capStoreService.addProduct(product);
		return "Product Successfully Added,ProductId is " + productId;
	}

	@GetMapping(value = "updateinventory/{productId}/{quantity}/{productprice}")
	public String updateInventory(@PathVariable("productId") int productId, @PathVariable("quantity") int quantity,
			@PathVariable("productprice") double productPrice) throws ProductException {
		return capStoreService.updateInventory(productId, quantity, productPrice);
	}

	@DeleteMapping(value = "deleteproduct/{productId}")
	public String deleteProduct(@PathVariable("productId") int productId) throws ProductException {
		return capStoreService.deleteProduct(productId);
	}

	@GetMapping(value = "searchByProductId/{merchantid}/{productid}")
	public Product searchByProductId(@PathVariable("merchantid") int merchantId,
			@PathVariable("productid") int productId) throws ProductException {
		return capStoreService.searchByProductId(merchantId, productId);
	}

	@GetMapping(value = "searchByOrderId/{merchantid}/{orderid}")
	public List<Product> searchByOrderId(@PathVariable("merchantid") int merchantId,
			@PathVariable("orderid") int orderId) throws ProductException, MerchantException {
		return capStoreService.searchByOrderId(merchantId, orderId);
	}

	@GetMapping(value = "loginMerchant/{merchantId}/{password}")
	public boolean loginMerchant(@PathVariable("merchantId") int merchantId, @PathVariable("password") String password)
			throws MerchantException {

		return capStoreService.loginMerchant(merchantId, password);
	}

	@GetMapping(value = "listAllProducts/{merchantId}")
	public List<Product> listAllProducts(@PathVariable("merchantId") int merchantId) throws MerchantException {
		return capStoreService.listAllProducts(merchantId);
	}

	@PostMapping(value = "uploadimagemerchant/{productid}/{imagelink}")
	public boolean uploadImagemerchant(@PathVariable("productid") int productId,
			@PathVariable("imagelink") String imageLink) {
		int imageId=capStoreService.uploadImagemerchant(productId, imageLink);
		return true;
	}

	@PostMapping(value = "addcategory", produces = MediaType.TEXT_PLAIN_VALUE)
	public String addCategory(@RequestBody Category category) {
		int categoryId = capStoreService.addCategory(category);
		return "Category Successfully Added,CategoryId is " + categoryId;
	}

	@GetMapping(value = "listOrders/{merchantId}")
	public List<OrderQuantityProduct> listOrders(@PathVariable("merchantId") int merchantId) throws CapStoreException {
		return capStoreService.listOrders(merchantId);
	}

	@GetMapping(value = "updateProductStatusByMerchant/{id}/{flag}")
	public boolean updateProductStatusByMerchant(@PathVariable("id") int id, @PathVariable("flag") boolean flag)
			throws CapStoreException {
		return capStoreService.updateProductStatusByMerchant(id, flag);
	}

// customer team1 work###########################################################################################
	@GetMapping(value = "customer/{cust_id}")
	public Customer get(@PathVariable("cust_id") int cust_id) throws CapStoreException {

		return capStoreService.getCustomer(cust_id);
	}

	@GetMapping(value = "getProduct/{productId}")
	public Product getProduct(@PathVariable("productId") int productId) throws CapStoreException {
		return capStoreService.getProduct(productId);
	}

	@GetMapping(value = "updateAddress/{customerId}/{address}")
	public String updateAddress(@PathVariable("customerId") int customerId, @PathVariable("address") String address)
			throws CapStoreException {
		return capStoreService.updateAddress(customerId, address);
	}

	@GetMapping(value = "getYourOrder/{customerId}")
	public List<Order> getYourOrder(@PathVariable("customerId") int customerId) throws CapStoreException {
		return capStoreService.getYourOrders(customerId);
	}

	@PostMapping(value = "uploadimage/{productid}/{imagelink}", produces = MediaType.TEXT_PLAIN_VALUE)
	public String uploadImage(@PathVariable("productid") int productId, @PathVariable("imagelink") String imageLink) {
		int imageId = capStoreService.uploadImage(productId, imageLink);
		return "Images Successfully Added";
	}

	@GetMapping(value = "getCustomer/{customerId}")
	public Customer getCustomer(@PathVariable("customerId") int customerId) throws CapStoreException {
		return capStoreService.getCustomer(customerId);
	}

	
// customer team2 work###########################################################################################

//	/---------------------------------Customer Login controller------------------------------------------
	//cutomer login:
	// For eg.: (passing this uri in postman using 
	// get method(http://localhost:9090/loginCutomer/99/pagal))
	@GetMapping(value="loginCustomer/{customerId}/{password}")
	public boolean loginCustomer(@PathVariable("customerId") int customerId,@PathVariable("password") String password) throws CapStoreException 
	{	
		return capStoreService.loginCustomer(customerId, password);
	}
	
	
	
	//---------------------------------Searching Product------------------------------------------
	@GetMapping(value="search/{prod_name}")
	public List<Product> searchProduct(@PathVariable("prod_name") String prod_name) throws CapStoreException
	{
		List<Product> list = capStoreService.searchProduct(prod_name);
		
		return list;
	}
	//--------------------------Sorting Products on Different Parameters-------------------------

	
	// sorting products by mostly viewed:
	// For eg.: (passing this uri in postman using 
	// get method(http://localhost:9090/listProductByMostViewed))
	@GetMapping(value = "listProductByMostViewed")
	public List<ViewProduct> listProductByMostViewed() throws CapStoreException {
		return capStoreService.listProductByMostViewed();
	}

	// sorting products based on best seller:
	// For eg.: (passing this uri in postman using 
	// get method(http://localhost:9090/listProductByBestSeller))
	@GetMapping(value = "listProductByBestSeller")
	public List<ViewProduct> listProductByBestSeller() throws CapStoreException {
		return capStoreService.listProductBasedOnBestSeller();
	}

	// sorting products in Ascending Order:
	// For eg.: (passing this uri in postman using 
	// get method(http://localhost:9090/listProductPriceInAsc))
	@GetMapping(value = "listProductPriceInAsc")
	public List<Product> listProductPriceInAscOrder() throws CapStoreException {
		return capStoreService.listProductPriceInAscOrder();
	}

	// sorting products in Descending Order:
	// For eg.: (passing this uri in postman using 
	// get method(http://localhost:9090/listProductPriceInDesc))
	@GetMapping(value = "listProductPriceInDesc")
	public List<Product> listProductPriceInDescOrder() throws CapStoreException {
		return capStoreService.listProductPriceInDescOrder();
	}

	// sorting products in given price range:
	// For eg.: (passing this uri in postman using 
	// get method(http://localhost:9090/getProduct/price/500/16000))
	@GetMapping(value = "getProduct/price/{low}/{high}")
	public List<Product> getProductByPriceRange(@PathVariable("low") double low, @PathVariable("high") double high)
			throws CapStoreException {
		return capStoreService.getProductByPriceRange(low, high);
	}
	
	
	
	//---------------------------------Similar Products------------------------------------------

		//searching the product:
		// For eg.: (passing this uri in postman using 
		// get method(http://localhost:9090/similarProducts/phone))
		@GetMapping(value = "similarProducts/{prod_name}")
		public List<Product> listOfSimilarProducts(@PathVariable("prod_name") String prod_name) throws CapStoreException {
			List<Product> list = capStoreService.listOfSimilarProducts(prod_name);
			return list;
		}
	
	
	
	
	
	//--------------------------------------Managing Cart--------------------------------------
	
		//adding product to cart:
		@GetMapping(value="addproducttocart/{quantity}/{prodId}/{custId}")
		public String addProductToCart(@PathVariable("prodId") int prod_id,@PathVariable("custId") int cust_id,@PathVariable("quantity") int quantity) throws CapStoreException
		{
			capStoreService.addProductToCart(prod_id, cust_id, quantity);
		return "Product Addded to cart successfully";
		}
		
		
		//listing all products in cart:
		@GetMapping(value="listallproduct/{cust_id}")				//customer_id
		public List<CartQuantityProduct> listAllProduct(@PathVariable("cust_id") int Cust_id) throws CapStoreException
		{
			return capStoreService.listAllCartProduct(Cust_id);
		
		}
		
		
		//updating product in cart:
		@GetMapping(value="updateproductfromcart/{quantity}/{prodId}/{custId}")
		public String updateProduct(@PathVariable("prodId") int prod_id,@PathVariable("custId") int cust_id,@PathVariable("quantity") int quantity) throws CapStoreException
		{
			capStoreService.updateProductInCart(quantity, prod_id, cust_id);
			return "Successful";
		}
		
		
		//removing product in cart:
		@GetMapping(value="deleteproductfromcart/{prodId}/{custId}")
		public String removeProduct(@PathVariable("prodId") int prod_id,@PathVariable("custId") int cust_id) throws CapStoreException
		{
			capStoreService.removeProductFromCart(prod_id, cust_id);
		
			return "Removed";
		}
		
		
		
	//--------------------------------------Placing Order--------------------------------------

	//placing order:
	@PostMapping(value="addOrder/{cust_id}")
	public int addOrder(@PathVariable("cust_id") int cust_id ) throws CapStoreException
	{
		
		return capStoreService.placingOrder(cust_id);
	}
		
	
	
	//---------------------------------Getting Shipping Details-----------------------------------
	
	@GetMapping(value="ship/{order_id}")
	public List<OrderQuantityProduct> getShippingDetails(@PathVariable("order_id") int order_id) throws CapStoreException
	{
		return capStoreService.getShippingDetails(order_id);
	}

	
	
	//-----------------------------------Transaction Details-----------------------------------
	//getting transactional details:
	@PostMapping(value="addTransaction/{orderId}")
	public String addTransaction(@PathVariable("orderId")int orderId,@RequestBody Transaction transaction) throws CapStoreException
	{
		
		return capStoreService.transactionDetails(orderId, transaction)+" Your transaction id is: "+transaction.getTransactionId();
	}
}
