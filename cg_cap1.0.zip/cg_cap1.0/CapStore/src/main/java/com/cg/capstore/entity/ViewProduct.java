package com.cg.capstore.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="m_viewProduct")
public class ViewProduct  {

	
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getProductViewCount() {
		return productViewCount;
	}

	public void setProductViewCount(int productViewCount) {
		this.productViewCount = productViewCount;
	}

	public int getProductOrderCount() {
		return productOrderCount;
	}

	public void setProductOrderCount(int productOrderCount) {
		this.productOrderCount = productOrderCount;
	}

	@OneToOne
	@JoinColumn(name="prod_id")
	private Product product;
	
	@Column(name="prod_view_count")
	private int productViewCount;
	
	@Column(name="prod_order_count")
	private int productOrderCount;
	
}
