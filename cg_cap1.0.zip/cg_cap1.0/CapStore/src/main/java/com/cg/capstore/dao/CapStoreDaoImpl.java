package com.cg.capstore.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.entity.CartQuantityProduct;
import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.CustomerLoginPassword;
import com.cg.capstore.entity.Image;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.MerchantLoginPassword;
import com.cg.capstore.entity.Order;
import com.cg.capstore.entity.OrderQuantityProduct;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.Transaction;
import com.cg.capstore.entity.ViewProduct;
import com.cg.capstore.exception.CapStoreException;
import com.cg.capstore.exception.MerchantException;
import com.cg.capstore.exception.ProductException;

@Repository
@Transactional
public class CapStoreDaoImpl implements CapStoreDao {

	@PersistenceContext
	EntityManager entityManager;
	
	private static String hashPassword(String plainTextPassword){
		return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
	}
	
	private static boolean checkPass(String plainPassword, String hashedPassword) {
		boolean flag=false;
		if (BCrypt.checkpw(plainPassword, hashedPassword)) {
			flag=true;
		}
		return flag;
		
	}

	@Override
	public String placingOrder(Order order, OrderQuantityProduct orderQuantityProduct) throws CapStoreException {
		Customer customer = entityManager.find(Customer.class, order.getCustomer());
		order.setCustomer(customer);
		entityManager.persist(order);
		entityManager.persist(orderQuantityProduct);
		return "id is" + order.getOrderId();
	}

	// Admin
	@Override
	public Customer getCustomeradmin(int cust_id) throws CapStoreException {
		Customer customer = entityManager.find(Customer.class, cust_id);
		return customer;
	}

	@Override
	public List<Customer> getAllCustomer() throws CapStoreException {
		TypedQuery<Customer> query = entityManager.createQuery("from Customer", Customer.class);
		List<Customer> customerList = query.getResultList();
		return customerList;
	}

	@Override
	public List<Merchant> getAllMerchant() throws CapStoreException {
		TypedQuery<Merchant> query = entityManager.createQuery("from Merchant", Merchant.class);

		List<Merchant> merchantList = query.getResultList();

		Collections.sort(merchantList);
		merchantList.remove(0);
		return merchantList;
	}

	@Override
	public List<Product> getAllProducts() throws CapStoreException {
		TypedQuery<Product> query = entityManager.createQuery("from Product", Product.class);
		List<Product> productList = query.getResultList();
		return productList;
	}

	@Override
	public List<Order> getAllOrders() throws CapStoreException {
		TypedQuery<Order> query = entityManager.createQuery("from Order", Order.class);
		List<Order> orderList = query.getResultList();
		return orderList;
	}

	@Override
	public boolean manageMerchant(int merchantId, boolean flag) throws CapStoreException {
		Merchant merchant = entityManager.find(Merchant.class, merchantId);
		if (merchant.getMerchantAuthorization() == null) {
			if (flag == true) {
				merchant.setMerchantAuthorization("approved");
			} else {
				merchant.setMerchantAuthorization("rejected");
			}
			entityManager.merge(merchant);
		}

		return flag;
	}

	@Override
	public boolean updateProductStatusByAdmin(int id, boolean flag) throws CapStoreException {
		boolean status = false;
		OrderQuantityProduct orderQuantityProduct = entityManager.find(OrderQuantityProduct.class, id);
		if (orderQuantityProduct.getStatus().equals("shipped")) {
			if (flag) {
				orderQuantityProduct.setStatus("delivered");
				status = true;
			} else {
				orderQuantityProduct.setStatus("rejected");
			}
			entityManager.merge(orderQuantityProduct);
		}
		return status;
	}

	@Override
	public boolean removeMerchant(int merchantId) throws CapStoreException {
		boolean flag = false;
		Merchant merchant2 = entityManager.find(Merchant.class, 1);
				Merchant merchant = entityManager.find(Merchant.class, merchantId);
		List<Product> list = merchant.getProducts();
		System.out.println(list);
		for (Product product : list) {
			Product product1 = entityManager.find(Product.class, product.getProductId());
			product1.setMerchant(merchant2);
			entityManager.merge(product1);
		}
		 TypedQuery<MerchantLoginPassword> query = entityManager
		 .createQuery("From MerchantLoginPassword where merchant=:merch",
		 MerchantLoginPassword.class);
		 query.setParameter("merch", merchant);
		 MerchantLoginPassword merchantLoginPassword=query.getSingleResult();
		
		 entityManager.remove(merchantLoginPassword);
		
		
		entityManager.remove(merchant);
		flag = true;

		return flag;
	}

	@Override
	public List<Integer> getDispatchReport(int productId) throws CapStoreException {
		List<Integer> list = new ArrayList<Integer>();
		Map<Integer, Integer> map = new HashMap<>();
		map.put(1, 0);
		map.put(2, 0);
		map.put(3, 0);
		map.put(4, 0);
		map.put(5, 0);
		map.put(6, 0);
		map.put(7, 0);
		Date date;
		Product product = entityManager.find(Product.class, productId);
		List<OrderQuantityProduct> orderQuantityProducts = product.getListOrderQuantity();

		for (OrderQuantityProduct product2 : orderQuantityProducts) {
			date = product2.getOrder().getOrderDate();
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			int weekday = calendar.get(Calendar.DAY_OF_WEEK);
			map.put(weekday, map.get(weekday) + product2.getQuantity());

		}

		Collection<Integer> collection = map.values();
		for (Integer integer : collection) {
			list.add(integer);
		}

		System.out.println(list);
		return list;
	}

	@Override
	public List<Integer> getDispatchReportCategoryall() throws CapStoreException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Integer> getDispatchReportsubcatgory(String category) throws CapStoreException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Integer> getDispatchReportCategory(int categoryId) throws CapStoreException {
		List<Integer> list = new ArrayList<Integer>();
		Map<Integer, Integer> map = new HashMap<>();
		map.put(1, 0);
		map.put(2, 0);
		map.put(3, 0);
		map.put(4, 0);
		map.put(5, 0);
		map.put(6, 0);
		map.put(7, 0);
		Date date;
		List<Product> list2 = getAllProducts();
		list2 = list2.stream().filter(p -> p.getCategory().getCategoryId() == categoryId).collect(Collectors.toList());

		for (Product product : list2) {
			List<OrderQuantityProduct> orderQuantityProducts = product.getListOrderQuantity();

			for (OrderQuantityProduct product2 : orderQuantityProducts) {
				date = product2.getOrder().getOrderDate();
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(date);
				int weekday = calendar.get(Calendar.DAY_OF_WEEK);
				map.put(weekday, map.get(weekday) + product2.getQuantity());

			}

			Collection<Integer> collection = map.values();
			for (Integer integer : collection) {
				list.add(integer);
			}
		}

		System.out.println(list);
		return list;
	}

	@Override
	public List<Integer> getDispatchReportMerchant(int merchantId) throws CapStoreException {
		List<Integer> list = new ArrayList<Integer>();
		Map<Integer, Integer> map = new HashMap<>();
		map.put(1, 0);
		map.put(2, 0);
		map.put(3, 0);
		map.put(4, 0);
		map.put(5, 0);
		map.put(6, 0);
		map.put(7, 0);
		Date date;
		Merchant merchant = entityManager.find(Merchant.class, merchantId);
		for (Product product : merchant.getProducts()) {
			List<OrderQuantityProduct> orderQuantityProducts = product.getListOrderQuantity();

			for (OrderQuantityProduct product2 : orderQuantityProducts) {
				date = product2.getOrder().getOrderDate();
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(date);
				int weekday = calendar.get(Calendar.DAY_OF_WEEK);
				map.put(weekday, map.get(weekday) + product2.getQuantity());

			}

			Collection<Integer> collection = map.values();
			for (Integer integer : collection) {
				list.add(integer);
			}
		}

		System.out.println(list);
		return list;
	}

	@Override
	public List<Category> getAllcategory() throws CapStoreException {

		return entityManager.createQuery("From Category", Category.class).getResultList();
	}

	@Override
	public boolean customerSignUp(Customer customer, String password) throws CapStoreException {
		boolean flag = false;
		TypedQuery<Customer> query = entityManager.createQuery("FROM Customer where mobileNumber=:mnumber",
				Customer.class);

		query.setParameter("mnumber", customer.getMobileNumber());
		Customer customer2 = null;
		try {
			customer2 = query.getSingleResult();
			throw new CapStoreException("Mobile Number already exist");

		} catch (Exception e) {
			if (customer2 != null) {
				throw new CapStoreException("Mobile Number already exist");
			}

			Customer customer3 = null;
			query = entityManager.createQuery("from Customer where customerEmailId=:emailid", Customer.class);
			query.setParameter("emailid", customer.getCustomerEmailId());
			System.out.println(customer.getCustomerEmailId());
			try {

				customer3 = query.getSingleResult();
				
				throw new CapStoreException("EmailId already exist");
			} catch (Exception e1) {
				
				
				if (customer3 != null) {
					throw new CapStoreException("EmailId already exist");

				}

				entityManager.persist(customer);
				flag = true;
			}

		}

		 CustomerLoginPassword customerLoginPassword = new CustomerLoginPassword();
		 customerLoginPassword.setCustomer(customer);
		 customerLoginPassword.setPassword(CapStoreDaoImpl.hashPassword(password));
		 entityManager.persist(customerLoginPassword);

		return flag;
	}

	@Override
	public boolean merchantSignUp(Merchant merchant, String password) throws CapStoreException {
		boolean flag = false;
		TypedQuery<Merchant> query = entityManager.createQuery("FROM Merchant where mobileNumber=:mnumber",
				Merchant.class);

		query.setParameter("mnumber", merchant.getMobileNumber());
		Merchant merchant2 = null;
		try {
			merchant2 = query.getSingleResult();
			throw new CapStoreException("Mobile Number already exist");

		} catch (Exception e3) {
			if (merchant2 != null) {
				throw new CapStoreException("Mobile Number already exist");
			}

			merchant2 = null;
			query = entityManager.createQuery("FROM Merchant where merchantEmailId=:email", Merchant.class);
			query.setParameter("email", merchant.getMerchantEmailId());
			try {

				merchant2 = query.getSingleResult();
				throw new CapStoreException("EmailId already exist");
			} catch (Exception e4) {
				e4.printStackTrace();
				System.out.println(merchant2);
				if (merchant2 != null) {
					throw new CapStoreException("EmailId already exist");
				}

				entityManager.persist(merchant);
				flag = true;
			}

			MerchantLoginPassword merchantLoginPassword=new MerchantLoginPassword();
			 merchantLoginPassword.setMerchant(merchant);
			 merchantLoginPassword.setPassword(CapStoreDaoImpl.hashPassword(password));
			 entityManager.persist(merchantLoginPassword);

		}
		return flag;

	}

	// #######################################################################################################################
	// merchant
	@Override
	public int addProduct(Product product) {

		TypedQuery<Category> query = entityManager.createQuery("From Category where subCategory like :name",
				Category.class);

		query.setParameter("name", "%" + product.getCategory().getSubCategory() + "%");

		int id = query.getSingleResult().getCategoryId();
///@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@check for category and subcategory
		product.getCategory().setCategoryId(id);

		entityManager.persist(product);
		entityManager.close();

		return product.getProductId();
	}

	@Override
	public String updateInventory(int ProductId, int Quantity, double ProductPrice) throws ProductException {

		String Message = "";

		Product pro = entityManager.find(Product.class, ProductId);

		if (pro != null) {
			pro.setProductQuantity(Quantity);
			pro.setProductPrice(ProductPrice);
			entityManager.merge(pro);

			entityManager.close();
			Message = "UPDATED SUCCESSFULLY";
		} else {
			throw new ProductException("PRODUCT ID NOT FOUND");
		}
		return Message;
	}

	@Override
	public String deleteProduct(int ProductId) throws ProductException {
		String Message = "";
		Product pro = entityManager.find(Product.class, ProductId);
		if (pro != null) {
			entityManager.remove(pro);
			Message = "DELETED SUCCESSFULLY";
		} else {
			throw new ProductException("PRODUCT ID NOT FOUND");
		}
		return Message;
	}

	@Override
	public Product searchByProductId(int MerchantId, int productId) throws ProductException {
		Product product = entityManager.find(Product.class, productId);
		if (product != null) {
			if (product.getMerchant().getMerchantId() == MerchantId) {
				return product;

			} else {
				throw new ProductException("NO SUCH PRODUCT BELONGS TO THE MERCHANT");
			}

		} else {
			throw new ProductException("Product id not found");
		}

	}

	@Override
	public List<Product> searchByOrderId(int merchantId, int orderId) throws ProductException, MerchantException {

		List<Product> productList = new ArrayList<Product>();

		Order order = entityManager.find(Order.class, orderId);

		// entityManager.find(OrderQuantityProduct.class,orderId);

		if (order != null) {
			List<OrderQuantityProduct> list = order.getOrderQuantityProducts();

			for (OrderQuantityProduct quanproduct : list) {
				if (quanproduct.getProduct().getMerchant().getMerchantId() == merchantId) {
					productList.add(quanproduct.getProduct());
				}

			}
		} else {
			throw new ProductException("ORDER ID NOT FOUND");
		}

		if (productList.size() == 0) {
			throw new MerchantException("NO PRODUCTS FOUND IN THIS ORDER");
		}

		return productList;
	}

	@Override
	public boolean loginMerchant(int merchantId, String password) throws MerchantException {

		boolean status = false;

		Merchant merch = entityManager.find(Merchant.class, merchantId);

		if (merch.getMerchantAuthorization()==null) {
			throw new MerchantException("MERCHANT NOT APPROVED");
		}if(merch.getMerchantAuthorization().equalsIgnoreCase("approved")) {
			TypedQuery<MerchantLoginPassword> query = entityManager.createQuery(
					"From MerchantLoginPassword where merchant.merchantId = :id", MerchantLoginPassword.class);

			query.setParameter("id", merchantId);

			MerchantLoginPassword merchant = query.getSingleResult();

			if (merchant != null) {

				if (CapStoreDaoImpl.checkPass(password, merchant.getPassword())) {
					status = true;
				} else {
					throw new MerchantException("PASSWORD DOES NOT MATCH");
				}

			} else {
				throw new MerchantException("MERCHANT NOT FOUND");
			}
		

		
		}
		else {
			throw new MerchantException("Merchant Rejected");
		}
		
		return status;
	}

	@Override
	public List<Product> listAllProducts(int merchantId) throws MerchantException {

		TypedQuery<Merchant> query = entityManager.createQuery("FROM Merchant where merchantId = :id", Merchant.class);

		query.setParameter("id", merchantId);

		Merchant merchant = query.getSingleResult();

		List<Product> productList = merchant.getProducts();

		if (productList.size() != 0) {
			return productList;
		} else {
			throw new MerchantException("MERCHANT HAS NO PRODUCTS");
		}
	}

	@Override
	public int uploadImagemerchant(int productid, String imagelink) {
		Product product = entityManager.find(Product.class, productid);
		Image image = new Image();
		image.setImageLink(imagelink);
		image.setProduct(product);
		entityManager.persist(image);
		entityManager.close();
		return image.getId();
	}

	@Override
	public int addCategory(Category category) {
		entityManager.persist(category);
		entityManager.close();
		return category.getCategoryId();
	}

	@Override
	public List<OrderQuantityProduct> listOrders(int merchantId) {

		List<OrderQuantityProduct> list = new ArrayList<OrderQuantityProduct>();
		TypedQuery<Order> query = entityManager.createQuery("from Order", Order.class);
		List<Order> orderList = query.getResultList();

		for (Order o : orderList) {
			List<OrderQuantityProduct> l = o.getOrderQuantityProducts();

			for (OrderQuantityProduct quanproduct : l) {
				if (quanproduct.getProduct().getMerchant().getMerchantId() == merchantId) {
					list.add(quanproduct);
				}

			}
		}

		return list;
	}

	@Override
	public boolean updateProductStatusByMerchant(int id, boolean flag) throws CapStoreException {

		boolean status = false;
		OrderQuantityProduct orderQuantityProduct = entityManager.find(OrderQuantityProduct.class, id);
		if (orderQuantityProduct.getStatus().equals("placed")) {
			if (flag) {
				orderQuantityProduct.setStatus("shipped");
				status = true;
			} else {
				orderQuantityProduct.setStatus("rejected");
			}
			entityManager.merge(orderQuantityProduct);
		}
		return status;
	}

	// ########################################################################################
	@Override
	public Customer getCustomer(int cust_id) throws CapStoreException {
		Customer customer = entityManager.find(Customer.class, cust_id);
		if (customer == null) {
			throw new CapStoreException("Customer Not Found");
		} else {
			return customer;
		}
	}

	@Override
	public Product getProduct(int productId) throws CapStoreException {
		Product product = entityManager.find(Product.class, productId);
		if (product == null) {
			throw new CapStoreException("Product not found");
		} else {
			return product;
		}
	}

	@Override
	public String updateAddress(int customerId, String address) throws CapStoreException {
		Customer customer = entityManager.find(Customer.class, customerId);
		if (customer == null) {
			throw new CapStoreException("Customer Not Found");
		} else {
			customer.setAddress(address);
			entityManager.merge(customer);
			return customer.getAddress();
		}
	}

	@Override
	public List<Order> getYourOrders(int customerId) throws CapStoreException {
		Customer customer = entityManager.find(Customer.class, customerId);
//		List<Order> list=customer.getOrders();
		TypedQuery<Order> query = entityManager.createQuery("from Order where customer=:customers", Order.class);
		query.setParameter("customers", customer);
		List<Order> orders = query.getResultList();
		return orders;
	}

	///////////////////////////////////////////////////////////////////////////////////

	@Override
	public int uploadImage(int productid, String imagelink) {
		Product product = entityManager.find(Product.class, productid);
		Image image = new Image();
		image.setImageLink(imagelink);
		image.setProduct(product);
		entityManager.persist(image);
		entityManager.close();
		return image.getId();
	}

	@Override
	public String updateProfileDetails(Customer customer) throws CapStoreException {
		Customer customer2 = entityManager.find(Customer.class, customer.getCustomerId());
		customer2.setAddress(customer.getAddress());
		entityManager.merge(customer2);
		return "Successfully Updated";
	}

	
	
//Customer team 2****************************************************************************************************

	//---------------------------------Customer Login------------------------------------------
	@Override
	public boolean loginCustomer(int customerId, String password) throws CapStoreException {
		boolean str=false;
		
		TypedQuery<CustomerLoginPassword> query=entityManager.createQuery("From CustomerLoginPassword where customer.customerId = :id",CustomerLoginPassword.class);
		
		query.setParameter("id",customerId);
		
		CustomerLoginPassword customer=query.getSingleResult();
		
		if(customer!=null)
		{
			
			if(CapStoreDaoImpl.checkPass(password, customer.getPassword()))
			{
		         str=true;		
			}
			else
			{
				throw new CapStoreException("PASSWORD DOES NOT MATCH");
			}
			
		}
		else
		{
			throw new CapStoreException("CUSTOMER NOT FOUND");
		}
		
		return str;
	}

	
	//---------------------------------Searching Product from Home------------------------------------------
	@Override
	public List<Product> searchProduct(String prod_name) throws CapStoreException {
		List<Product> list = new ArrayList<Product>();
		TypedQuery<Product> query = entityManager.createQuery("From Product", Product.class);
		List<Product> products = query.getResultList();
		if(products!=null)
		{
		for (Product p : products) {
			String arr[] = p.getProductdescription().split(" ");
			for (int i = 0; i < arr.length; i++) {
				if (prod_name.matches("(.*)" + arr[i] + "(.*)")) {
					list.add(p);
				}
			}
		}
		return list;
		}
		else
		{
			throw new CapStoreException("No product found in the records Nothing In The Records");
		}
	
	}

	//---------------------------------Searching Product from Home------------------------------------------
	@Override
	public List<CartQuantityProduct> searchProductFromCart(String prod_name, int cust_id) throws CapStoreException {

		Customer customer=entityManager.find(Customer.class, cust_id);

					List<CartQuantityProduct> list = new ArrayList<CartQuantityProduct>();
					TypedQuery<CartQuantityProduct> query = entityManager.createQuery("From CartQuantityProduct where customer=:id", CartQuantityProduct.class);
					query.setParameter("id", customer);
					List<CartQuantityProduct> products = query.getResultList();
					if(products!=null)
					{
					for (CartQuantityProduct p : products) {
						String arr[] = p.getProduct().getProductdescription().split(" ");
						for (int i = 0; i < arr.length; i++) {
							if (prod_name.matches("(.*)" + arr[i] + "(.*)")) {
								list.add(p);
							}
					}
						
					}return list;}
					else
					{
						throw new CapStoreException("No product found in the records Nothing In The Records");

						}
	}
			
		
	
	//--------------------------Sorting Products on Different Parameters-------------------------	
	
	
	// sorting products by mostly viewed:
		@Override
		public List<ViewProduct> listProductByMostViewed() throws CapStoreException {
			TypedQuery<ViewProduct> query = entityManager.createQuery("FROM ViewProduct where productViewCount > 6  ",
					ViewProduct.class);
			List<ViewProduct> list = query.getResultList();
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
			return list;
			}
			}

		// sorting products based on best seller:
		@Override
		public List<ViewProduct> listProductBasedOnBestSeller() throws CapStoreException {
			TypedQuery<ViewProduct> query = entityManager.createQuery("FROM ViewProduct where productOrderCount > 6  ",
					ViewProduct.class);
			List<ViewProduct> list = query.getResultList();
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
				return list;
			}
			
		}

		// sorting products in Ascending Order:
		@Override
		public List<Product> listProductPriceInAscOrder() throws CapStoreException {
			TypedQuery<Product> query = entityManager.createQuery("FROM Product as p order by productPrice asc",
					Product.class);
			List<Product> list = query.getResultList();
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
			return list;
			}
			}

		// sorting products in Descending Order:
		@Override
		public List<Product> listProductPriceInDescOrder() throws CapStoreException {
			TypedQuery<Product> query = entityManager.createQuery("FROM Product as p order by productPrice desc  ",
					Product.class);
			List<Product> list = query.getResultList();
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
			return list;
		}
			}

		// sorting products in given price range:
		public List<Product> getProductByPriceRange(double low, double high) throws CapStoreException {
			TypedQuery<Product> query = entityManager.createQuery("from Product where productPrice between :low and :high",
					Product.class);
			query.setParameter("low", low);
			query.setParameter("high", high);
			List<Product> list = query.getResultList();
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
			return list;
		}
			}


		

		//=====================================Similar Products====================================
		public List<Product> listOfSimilarProducts(String prod_name) throws CapStoreException {
			
			List<Product> list=searchProduct(prod_name);
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
			return list;
		}
			}

		
		
		
		//--------------------------------------Managing Cart--------------------------------------
		
		//adding product to cart:
		@Override
		public String addProductToCart(int prod_id, int cust_id,int quantity) throws CapStoreException {
			Product product = entityManager.find(Product.class, prod_id);
			Customer customer=entityManager.find(Customer.class, cust_id);
			CartQuantityProduct cart=new CartQuantityProduct();
			cart.setQuantity(quantity);
			cart.setCustomer(customer);
			cart.setProduct(product);
			entityManager.persist(cart);
			return "Add to cart Successfully";
		}

		
		//listing all products in cart:
		@Override
		public List<CartQuantityProduct> listAllCartProduct(int cust_id) throws CapStoreException {
			
			Customer customer = entityManager.find(Customer.class, cust_id);

			TypedQuery<CartQuantityProduct> query=entityManager.createQuery("From CartQuantityProduct where customer=:id",CartQuantityProduct.class);
			query.setParameter("id", customer);
			List<CartQuantityProduct> list=query.getResultList();
			if(list.size()==0)
			{
				throw new CapStoreException("No records found!!!");
			}
			else
			{
			return list;
		}
			}

		
		//removing product from cart:
		@Override
		public String removeProductFromCart(int prod_id,int cust_id) throws CapStoreException {
		
			Customer customer=entityManager.find(Customer.class, cust_id);
			if(customer!=null)
			{
			Product product=entityManager.find(Product.class, prod_id);
			{
				if(product!=null)
				{
	                TypedQuery<CartQuantityProduct> query=entityManager.createQuery("FROM CartQuantityProduct where customer=:cust_id and product=:prod_id",CartQuantityProduct.class);

					query.setParameter("cust_id", customer);
					query.setParameter("prod_id", product);
					CartQuantityProduct cart=query.getSingleResult();
					entityManager.remove(cart);
				}
				else
				{
					throw new CapStoreException("Product Not Found");
				}
			}
			}
			else
			{
				throw new CapStoreException("Customer Does Not Found");
			}
			
			return "Product Removed Successfully";
		}

		
		//updating product in cart:
		@Override
		public String updateProductInCart(int quantity, int prod_id,int cust_id) throws CapStoreException {

			Customer customer=entityManager.find(Customer.class, cust_id);
			if(customer!=null)
			{
			Product product=entityManager.find(Product.class, prod_id);
			{
				if(product!=null)
				{	
					TypedQuery<CartQuantityProduct> query=entityManager.createQuery("FROM CartQuantityProduct where customer=:cust_id and product=:prod_id",CartQuantityProduct.class);
					query.setParameter("cust_id", customer);
					query.setParameter("prod_id", product);
					
					CartQuantityProduct cart=query.getSingleResult();
//					cart.setId(cart.getId());
					cart.setCustomer(customer);
					cart.setProduct(product);
					cart.setQuantity(quantity);
					entityManager.merge(cart);
				}
				else
				{
					throw new CapStoreException("Product Not Found");
				}
			}
			}
			else
			{
				throw new CapStoreException("Customer Does Not Found");
			}
			
			return "Product Updated Successfully";

		}
	
	
	
	//--------------------------------------Placing Order--------------------------------------
	@Override
	public int placingOrder(int customerId) throws CapStoreException {

		Order order=new Order();
		 Customer customer=entityManager.find(Customer.class,customerId);

		 order.setCustomer(customer);

		 order.setOrderShippingAddress(customer.getAddress());

		 order.setOrderStatus("placed");

		 order.setOrderDate(Date.valueOf(LocalDate.now()));

		 order.setOrderTime(LocalTime.now().toString());

		 entityManager.persist(order);

		 List<CartQuantityProduct> list=customer.getCartQuantityProducts();

		 OrderQuantityProduct orderQuantityProduct=null;

		 for(CartQuantityProduct cart:list) {

		  orderQuantityProduct=new OrderQuantityProduct();

		  orderQuantityProduct.setOrder(order);

		  orderQuantityProduct.setProduct(cart.getProduct());
orderQuantityProduct.setStatus("placed");
		  orderQuantityProduct.setQuantity(cart.getQuantity());

		  orderQuantityProduct.setAmount(cart.getProduct().getProductPrice()*cart.getQuantity());
		 }
entityManager.persist(orderQuantityProduct);
		 return order.getOrderId();

		 }
		
		
		
	//---------------------------------Getting Shipping Details-----------------------------------
	@Override
	public List<OrderQuantityProduct> getShippingDetails(int order_id) throws CapStoreException {
		Order order = entityManager.find(Order.class, order_id);
		if (order != null) {

			TypedQuery<OrderQuantityProduct> query = entityManager
					.createQuery("FROM OrderQuantityProduct where order=:order_id", OrderQuantityProduct.class);

			query.setParameter("order_id", order);

			List<OrderQuantityProduct> list = query.getResultList();
			return list;
		} else {
			throw new CapStoreException("Order Does Not Found");
		}

	}
	
	
	//-----------------------------------Transaction Details-----------------------------------
			@Override
			public String transactionDetails(int OrderId ,Transaction transaction) throws CapStoreException {
				Order order=entityManager.find(Order.class, OrderId);
				transaction.setOrder(order);
				transaction.setTransactionDate(Date.valueOf(LocalDate.now()));
				transaction.setTransactionTime(LocalTime.now().toString());
				transaction.setTransactionStatus("Succesfull");
				entityManager.persist(transaction);
				
				return "Transaction Successfull ";
			}



}
