package com.cg.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="g_merchant_login_pass_tbl")
public class MerchantLoginPassword  {

	
	

	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	
	
	@OneToOne
	@JoinColumn(name="merch_id")
	private Merchant merchant;
	
	
	@Column(name="password",length=100)
	private String password;


	public Merchant getMerchant() {
		return merchant;
	}


	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
