package com.cg.capstore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="b_merchant_tbl")
public class Merchant implements Comparable<Merchant> {
	
	
	@Id
	@GeneratedValue
	@Column(name="merch_id")
	private int merchantId;
	
	@Column(name="mobile_num", length=10)
	private String mobileNumber;
	
	@Column(name="merch_name",length=30)
	private String merchantName;
	
	@Column(name="merch_mailid",length=30)
	private String merchantEmailId;
	
	@Column(name="merch_pan",length=10)
	private String merchantPanNo;
	
	@Column(name="merch_gst",length=20)
	private String merchantGstNo;
	
	@Column(name="merch_bank_name",length=30)
	private String merchantBankName;
	
	@Column(name="merch_bank_account",length=16)
	private String merchantBankAccountNo;
	
	@Column(name="merch_bank_ifsc",length=15)
	private String merchantBankIfscNo;
	
	@Column(name="merch_authorization",length=20)
	private String merchantAuthorization;
	
	@Column(name="merch_address",length=100)
	private String address;
	
	@JsonIgnore
	@OneToMany(mappedBy="merchant",targetEntity=Product.class)
	private List<Product> products=new ArrayList<Product>();
	
//	@OneToMany(mappedBy="product.getMerchant()",targetEntity=OrderQuantityProduct.class)
//	private List<OrderQuantityProduct> orderQuantityProducts=new ArrayList<>();

	

	public String getMobileNumber() {
		return mobileNumber;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantEmailId() {
		return merchantEmailId;
	}

	public void setMerchantEmailId(String merchantEmailId) {
		this.merchantEmailId = merchantEmailId;
	}

	public String getMerchantPanNo() {
		return merchantPanNo;
	}

	public void setMerchantPanNo(String merchantPanNo) {
		this.merchantPanNo = merchantPanNo;
	}

	public String getMerchantGstNo() {
		return merchantGstNo;
	}

	public void setMerchantGstNo(String merchantGstNo) {
		this.merchantGstNo = merchantGstNo;
	}

	public String getMerchantBankName() {
		return merchantBankName;
	}

	public void setMerchantBankName(String merchantBankName) {
		this.merchantBankName = merchantBankName;
	}

	public String getMerchantBankAccountNo() {
		return merchantBankAccountNo;
	}

	public void setMerchantBankAccountNo(String merchantBankAccountNo) {
		this.merchantBankAccountNo = merchantBankAccountNo;
	}

	public String getMerchantBankIfscNo() {
		return merchantBankIfscNo;
	}

	public void setMerchantBankIfscNo(String merchantBankIfscNo) {
		this.merchantBankIfscNo = merchantBankIfscNo;
	}

	public String getMerchantAuthorization() {
		return merchantAuthorization;
	}

	public void setMerchantAuthorization(String merchantAuthorization) {
		this.merchantAuthorization = merchantAuthorization;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public int compareTo(Merchant o) {
		
		return this.merchantId-o.merchantId;
	}

//	public List<OrderQuantityProduct> getOrderQuantityProducts() {
//		return orderQuantityProducts;
//	}
//
//	public void setOrderQuantityProducts(List<OrderQuantityProduct> orderQuantityProducts) {
//		this.orderQuantityProducts = orderQuantityProducts;
//	}
	

 
}
