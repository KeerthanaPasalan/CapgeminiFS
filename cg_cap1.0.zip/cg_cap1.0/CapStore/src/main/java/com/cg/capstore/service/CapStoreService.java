package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.entity.CartQuantityProduct;
import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Order;
import com.cg.capstore.entity.OrderQuantityProduct;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.Transaction;
import com.cg.capstore.entity.ViewProduct;
import com.cg.capstore.exception.CapStoreException;
import com.cg.capstore.exception.MerchantException;
import com.cg.capstore.exception.ProductException;

public interface CapStoreService {
//#admin work################################################################################
		public Customer getCustomeradmin(int cust_id) throws CapStoreException;
		public String placingOrder(Order order,OrderQuantityProduct orderQuantityProduct) throws CapStoreException;
		public List<Customer> getAllCustomer() throws CapStoreException;
		public List<Merchant> getAllMerchant() throws CapStoreException;
		public List<Product> getAllProducts() throws CapStoreException;
		public List<Order> getAllOrders() throws CapStoreException;
		public boolean manageMerchant(int merchantId,boolean flag) throws CapStoreException;
		public boolean updateProductStatusByAdmin(int id,boolean flag) throws CapStoreException;
		public boolean removeMerchant(int merchantId)throws CapStoreException;
		public List<Integer> getDispatchReport(int productId) throws CapStoreException;
		public List<Integer> getDispatchReportCategoryall() throws CapStoreException;
		public List<Integer> getDispatchReportsubcatgory(String category) throws CapStoreException;
		public List<Integer> getDispatchReportCategory(int productId) throws CapStoreException;
		public List<Integer>  getDispatchReportMerchant(int merchantId) throws CapStoreException;
		public List<Category> getAllcategory()throws CapStoreException;
		//SignUp and Activation
		public boolean customerSignUp(Customer customer,String password)throws CapStoreException;
		public boolean merchantSignUp(Merchant merchant,String password)throws CapStoreException;
		//merchant work#############################################################################
		public int addProduct(Product product);
		public String updateInventory(int ProductId,int Quantity,double ProductPrice)throws ProductException;
		public String deleteProduct(int ProductId)throws ProductException;
		public Product searchByProductId(int MerchantId,int productId) throws ProductException;
		public List<Product> searchByOrderId(int merchantId, int orderId) throws ProductException,MerchantException ;
		public boolean loginMerchant(int merchantId,String password) throws MerchantException;
		public List<Product> listAllProducts(int merchantId) throws MerchantException;
		public int uploadImagemerchant(int productid,String imagelink);
		public int addCategory(Category category);
		public List<OrderQuantityProduct> listOrders(int merchantId);
		public boolean updateProductStatusByMerchant(int id,boolean flag) throws CapStoreException;
//#customer team1 work##########################################################################
		
		public Customer getCustomer(int cust_id) throws CapStoreException;
		public String updateProfileDetails(Customer customer) throws CapStoreException;
		
		 public Product getProduct(int productId) throws CapStoreException;
		 public String updateAddress(int customerId,String address) throws CapStoreException;
		 public List<Order> getYourOrders(int customerId) throws CapStoreException;
		 public int uploadImage(int productid, String imagelink);

//#customer team2 work##########################################################################
			//---------------------------------Customer Login------------------------------------------
			public boolean loginCustomer(int customerId,String password) throws CapStoreException;
			
			
			
			//---------------------------------Searching Product------------------------------------------
			public List<Product> searchProduct(String prod_name) throws CapStoreException;
			
			//---------------------------------Searching Product------------------------------------------
			public List<CartQuantityProduct> searchProductFromCart(String prod_name,int cust_id) throws CapStoreException ;

			
			//--------------------------Sorting Products on Different Parameters-------------------------
			
			// sorting products by mostly viewed:
			public List<ViewProduct> listProductByMostViewed() throws CapStoreException;

			// sorting products based on best seller:
			public List<ViewProduct> listProductBasedOnBestSeller() throws CapStoreException;

			// sorting products in Ascending Order:
			public List<Product> listProductPriceInAscOrder() throws CapStoreException;

			// sorting products in Descending Order:
			public List<Product> listProductPriceInDescOrder() throws CapStoreException;

			// sorting products in given price range:
			public List<Product> getProductByPriceRange(double low, double high) throws CapStoreException;
			
			
			
			//=====================================Similar Products====================================
			public List<Product> listOfSimilarProducts(String prod_name) throws CapStoreException;
			
			
			//--------------------------------------Managing Cart--------------------------------------
			
			//adding product to cart:
			public String addProductToCart(int prod_id,int cust_id,int quantity)throws CapStoreException;
			
			//listing all products in cart:
			public List<CartQuantityProduct> listAllCartProduct(int Cust_id)throws CapStoreException;
			
			//removing product from cart:
			public String removeProductFromCart(int prod_id,int cust_id)throws CapStoreException;
			
			//updating product in cart:
			public String updateProductInCart(int quantity,int prod_id,int cust_id)throws CapStoreException;

			
			//--------------------------------------Placing Order--------------------------------------
			public int placingOrder(int customerId) throws CapStoreException;
				
			
			//---------------------------------Getting Shipping Details-----------------------------------
				public List<OrderQuantityProduct> getShippingDetails(int order_id) throws CapStoreException;

				
			//-----------------------------------Transaction Details-----------------------------------
			public String transactionDetails(int OrderId ,Transaction transaction) throws CapStoreException;


}
