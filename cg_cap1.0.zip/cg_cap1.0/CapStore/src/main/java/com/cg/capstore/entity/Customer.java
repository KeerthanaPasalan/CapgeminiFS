package com.cg.capstore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="a_customer_tbl")
public class Customer {
	
	
	@Id
	@GeneratedValue
	@Column(name="cust_id")
	private int customerId;
	
	@Column(name="mobile_num", length=10)
	private String mobileNumber;
	
	@Column(name="cust_name",length=30)
	private String customerName;
	
	@Column(name="cust_mailid",length=30)
	private String customerEmailId;
	
	@Column(name="cust_address",length=100)
	private String address;
	
	@JsonIgnore
	@OneToMany(mappedBy="customer",targetEntity=CartQuantityProduct.class)
	private List<CartQuantityProduct> cartQuantityProducts=new ArrayList<>();
	
	@JsonIgnore
	@OneToMany(mappedBy="customer",targetEntity=Order.class)
	private List<Order> orders=new ArrayList<>();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<CartQuantityProduct> getCartQuantityProducts() {
		return cartQuantityProducts;
	}

	public void setCartQuantityProducts(List<CartQuantityProduct> cartQuantityProducts) {
		this.cartQuantityProducts = cartQuantityProducts;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	

}
