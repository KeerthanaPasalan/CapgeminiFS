package com.cg.capstore.exception;

public class MerchantException extends Exception{
    public MerchantException(String message)
    {
    	super(message);
    }
}
