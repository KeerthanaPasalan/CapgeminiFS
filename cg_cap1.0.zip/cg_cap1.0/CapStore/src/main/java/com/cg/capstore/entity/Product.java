package com.cg.capstore.entity;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="d_product_tbl")
public class Product {
	
	
	@Id
	@GeneratedValue
	@Column(name="prod_id")
	private int productId;
	
	@Column(name="prod_name",length=30)
	private String productName;
	
	@Column(name="prod_price")
	private double productPrice;
	
	@Column(name="prod_desc",length=50)
	private String productdescription;
	
	@Column(name="prod_Brand")
	private String productBrand;
	
	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public List<Image> getImageList() {
		return imageList;
	}

	public void setImageList(List<Image> imageList) {
		this.imageList = imageList;
	}

	@OneToOne
	@JoinColumn(name="category_id")
	private Category category;
	
	
	
	
	@Column(name="prod_quantity")
	private int productQuantity;

	@OneToOne
	@JoinColumn(name="merch_id")
	private Merchant merchant;

	@OneToMany(mappedBy="product",targetEntity=Image.class)
	List<Image> imageList=new ArrayList<Image>();
	
	@JsonIgnore
	@OneToMany(mappedBy="product",targetEntity=OrderQuantityProduct.class)
	List<OrderQuantityProduct> listOrderQuantity=new ArrayList<OrderQuantityProduct>();

	
	
	public List<OrderQuantityProduct> getListOrderQuantity() {
		return listOrderQuantity;
	}

	public void setListOrderQuantity(List<OrderQuantityProduct> listOrderQuantity) {
		this.listOrderQuantity = listOrderQuantity;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

//	public List<Image> getImageList() {
//		return imageList;
//	}
//
//	public void setImageList(List<Image> imageList) {
//		this.imageList = imageList;
//	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductdescription() {
		return productdescription;
	}

	public void setProductdescription(String productdescription) {
		this.productdescription = productdescription;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	
	

}
