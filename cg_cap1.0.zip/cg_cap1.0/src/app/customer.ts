export class Customer
{
    customerId:number
    mobileNumber:string
    customerName:string
    customerEmailId:string
    address:string
}