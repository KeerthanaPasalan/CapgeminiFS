import { OrderQuantityProduct } from './orderquantityproduct';

export class Order {

    orderId: number;
    orderDate: string;
    orderTime: string;
    orderShippingAddress: string;
    orderStatus: string;
    orderQuantityProducts: OrderQuantityProduct

}