import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { Customer } from '../customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  customer: Customer = new Customer();
  name: string
  phoneNumber: number
  emailId: string
  address: string
  message: string
  constructor(private service: CapStoreService, private route: Router) { }

  ngOnInit() {
    this.service.getCustomerDetails(103).subscribe(data => {
      this.customer.customerId = data['customerId']
      this.customer.customerName = data['customerName']
      this.customer.mobileNumber = data['mobileNumber']
      this.customer.customerEmailId = data['customerEmailId']
      this.customer.address = data['address']

    })


  }

  editProfile() {
    this.service.editProfile(this.customer).subscribe(data => this.message = data);
  }

  yourOrder() {
    console.log('clicked')
    this.route.navigate(['yourOrder']);
  }

}
