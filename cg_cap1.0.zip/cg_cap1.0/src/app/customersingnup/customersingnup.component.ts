import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-customersingnup',
  templateUrl: './customersingnup.component.html',
  styleUrls: ['./customersingnup.component.css']
})
export class CustomersingnupComponent implements OnInit {

 
  





customer:Customer=new Customer();
password:string
status=false
errorMessage:string
  constructor(private service:CapstoreService) { }

  ngOnInit() {
  }
  onSubmit(){
    
    this.service.customerSignup(this.customer,this.password).subscribe(data=>{
      if(data["errorMessage"]!=undefined){
        this.errorMessage=data["errorMessage"];
        this.status=false;
      }
      else{
        this.status=data;
      }

    });
  }
}



