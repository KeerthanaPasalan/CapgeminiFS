import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { Router } from '@angular/router';
import { Order } from '../order';

@Component({
  selector: 'app-yourorder',
  templateUrl: './yourorder.component.html',
  styleUrls: ['./yourorder.component.css']
})
export class YourorderComponent implements OnInit {
  orders: Order[]
customerId:number=95
  constructor(private service:CapStoreService,private route:Router) { }

  ngOnInit() {
    this.service.getYourOrders(this.customerId).subscribe(data=>this.orders=data)
  }
  return()
  {
    this.route.navigate(['returngood'])
  }

}
