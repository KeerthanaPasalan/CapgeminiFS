export class CapStoreURL
{
     static readonly URL: string = "http://localhost:9090"
}