import { Component, OnInit } from '@angular/core';
import { Product } from '../productlist/product';
import { CapStoreService } from '../cap-store.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {

  message:string;
  product : Product=new Product();
prod_id:number
selectedquantity:number=1
  constructor(private service:CapStoreService,public routes:Router,private route : ActivatedRoute) { }

  ngOnInit() {
    this.prod_id=parseInt(this.route.snapshot.paramMap.get('prod_id'))
    this.service.getProduct(this.prod_id).subscribe(data=>this.product=data)
  }

  addtocart()
  {
    let customerId=parseInt(sessionStorage.getItem('custId'))
    this.service.addtocart(this.selectedquantity,this.product.productId,customerId).subscribe(data=>this.message=data)
    
  }

  buynow()
  {
    let customerId=parseInt(sessionStorage.getItem('customerid'))
    // this.service.buynow(customerId).subscribe(data=>this.message=data)
  }

  

}
