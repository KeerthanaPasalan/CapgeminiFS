import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import { Chart } from 'chart.js';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-dis-category',
  templateUrl: './dis-category.component.html',
  styleUrls: ['./dis-category.component.css']
})
export class DisCategoryComponent implements OnInit {
productCount:number[];
BarChart=[];
errorMessage:string;
allcategory:Category [];
  constructor(private service:CapstoreService) { }

  ngOnInit() {
    this.service.getAllCategory().subscribe(data=>this.allcategory=data);
  }

  onsumbit(category:Category){

    this.service.getDispatchReportCategory(category.categoryId).subscribe(data=>this.productCount=data);

    this.BarChart= new Chart('linechart2', {
        type: 'bar',
        data: {
            labels: ['Sunday','Monday', 'Tuesday', 'Wednesday', 'Thrusday', 'Friday', 'Saturday'],
            datasets: [{
                label: 'Number of Product Sold',
                data: this.productCount,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(155, 139, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(155, 139, 64, 0.2)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });







}

}
