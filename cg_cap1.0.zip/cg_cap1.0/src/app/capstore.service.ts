import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
import { CapStoreURL } from './CapstoreWebUrl';
import { Observable } from 'rxjs';
import { Merchant } from './merchant';
import { Product } from './product';
import { Order } from './order';
import { Category } from './category';

@Injectable({
  providedIn: 'root'
})
export class CapstoreService {

  constructor(private http:HttpClient) { }

  getAllCustomers():Observable<Customer []>
  {
    return this.http.get<Customer []>(CapStoreURL.url+"getAllCustomers");
  }

  
  getAllMerchants():Observable<Merchant []>
  {
    return this.http.get<Merchant []>(CapStoreURL.url+"getAllMerchants");
  }
  getAllProducts():Observable<Product []>
  {
    return this.http.get<Product []>(CapStoreURL.url+"getAllProducts");
  }
  manageMerchant(merchantId:number,flag:boolean)
  {
    return this.http.get(CapStoreURL.url+"manageMerchant/"+merchantId+"/"+flag);
  }

  getAllOrders()
  {
    return this.http.get<Order []>(CapStoreURL.url+"getAllOrders");
  }
  
  updateProductStatusByAdmin(id:number,flag:boolean):Observable<boolean>
  {
    return this.http.get<boolean>(CapStoreURL.url+"updateProductStatusByAdmin/"+id+"/"+flag);
  }
  getDispatchReport(productId:number):Observable<number []>
  {
    return this.http.get<number []>(CapStoreURL.url+"dispatchreportproduct/"+productId);

  }
  getDispatchReportCategoryall()
  {
    return this.http.get(CapStoreURL.url+"dispatchreportcategoryall");

  }
  getDispatchReportsubcatgory(category:string)
  {
    return this.http.get(CapStoreURL.url+"dispatchreportsubcategory/"+category);

  }
  getDispatchReportCategory(categoryId:number):Observable<number []>
  {
    return this.http.get<number []>(CapStoreURL.url+"dispatchreportcategory/"+categoryId);

  }
  getDispatchReportMerchant(merchantId:number):Observable<number []>
  {
    return this.http.get<number []>(CapStoreURL.url+"dispatchreportmerchant/"+merchantId);

  }
  removeMerchant(merchantId:number)
  {
    return this.http.get(CapStoreURL.url+"removeMerchant/"+merchantId);
  }
  getAllCategory():Observable<Category []>
  {
return this.http.get<Category []>(CapStoreURL.url+"getallcategory");
  }

 
  customerSignup(customer:Customer,password:string):Observable<boolean>
  {
return this.http.post<boolean>(CapStoreURL.url+"customersignup/"+password,customer)
  }

  merchantSignUp(merchant:Merchant,password:string):Observable<boolean>{
    return this.http.post<boolean>(CapStoreURL.url+"merchantsignup/"+password,merchant)
  }

}
