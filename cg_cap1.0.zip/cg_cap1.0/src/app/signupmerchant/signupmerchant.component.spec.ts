import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignupmerchantComponent } from './signupmerchant.component';

describe('SignupmerchantComponent', () => {
  let component: SignupmerchantComponent;
  let fixture: ComponentFixture<SignupmerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignupmerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignupmerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
