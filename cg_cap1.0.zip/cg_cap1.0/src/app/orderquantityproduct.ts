import { Order } from './order';
import { Product } from './productlist/product';

export class OrderQuantityProduct
{
    id: number;
    order: Order;	
    product: Product;
    quantity: number;
    amount: number;
    status: String;

}