export class Merchant
{
    merchantId : number;
    mobileNumber : string;
    merchantName : string;
    merchantEmailId : string;
    merchantPanNo : string;
    merchantGstNo : string;
    merchantBankName : string;
    merchantBankAccountNo : string;
    merchantAuthorization : string;
}