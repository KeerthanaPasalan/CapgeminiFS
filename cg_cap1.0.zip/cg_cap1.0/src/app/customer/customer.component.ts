import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Customer } from '../customer';
import { Order } from '../order';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customers:Customer[];
  
  constructor(private service:CapstoreService) { }

  ngOnInit() {
    this.service.getAllCustomers().subscribe(data=>this.customers=data);
    
  }

}
