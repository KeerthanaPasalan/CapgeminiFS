import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'app-merchantpage',
  templateUrl: './merchantpage.component.html',
  styleUrls: ['./merchantpage.component.css']
})
export class MerchantpageComponent implements OnInit {

  

  status : boolean=false;
  constructor(private  router : Router) { }

  ngOnInit() {
  }

  search()
  {
    this.status=true;
  }

  searchByOrder()
  {
    this.router.navigate(["/searchByOrder"]);
  }
  
   myFunctions() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
}

