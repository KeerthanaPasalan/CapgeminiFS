import { Injectable } from '@angular/core';
import { Product } from './productlist/product';
import { HttpClient } from '@angular/common/http';
import { ViewProduct } from './viewProduct';
import { Observable } from 'rxjs';
import { Order } from './order';
import { Customer } from './customer';
import { CapStoreURL } from 'src/app/capstoreUrl';
import { CartQuantityProduct } from 'src/app/cart/listProduct';
import { Transaction } from 'src/app/transaction';
import {  OrderQuantityProduct } from './orderquantityproduct';

@Injectable({
  providedIn: 'root'
})
export class CapStoreService {

  constructor(private http:HttpClient) { }
  
  public loginCustomer(customerId : number,password: string)
  {

    return this.http.get(CapStoreURL.URL+"/loginCustomer/"+customerId+"/"+password);
  }

  public deleteProduct(prodId:number,custId:number)
  {
    return this.http.get(CapStoreURL.URL+"/deleteproductfromcart/"+prodId+"/"+custId,{responseType:'text'})
  }
  
  public updateProduct(quantity,prodId,custId)
  {
    return this.http.get(CapStoreURL.URL+"/updateproductfromcart/"+quantity+"/"+prodId+"/"+custId,{responseType:'text'})
  }
  public listAllProduct(custId):Observable<CartQuantityProduct[]>
  {
    return this.http.get<CartQuantityProduct[]>(CapStoreURL.URL+"/listallproduct/"+custId)
  }
  public search(productname: string)
  {
    return this.http.get<Product []>(CapStoreURL.URL+"/search/"+productname);
  }

  public shipping(id:number)
  {
    return this.http.get(CapStoreURL.URL+"/ship/"+id);
  } 

  public getProduct(productId :number)
  {
    return this.http.get<Product>(CapStoreURL.URL+"/getProduct/"+productId)
  }

  public addtocart(productQuantity:number,productId:number,customerId:number)
  {
    return this.http.get(CapStoreURL.URL+"/addproducttocart/"+productQuantity+"/"+productId+"/"+customerId,{responseType:'text'})
  }

  public buynow(customerId:number )
  {
    return this.http.post<number>(CapStoreURL.URL+"/addOrder/"+customerId,{responseType:'number'})
  }

  public listOfMostViewed(): Observable<ViewProduct[]>
  {
    return this.http.get<ViewProduct[]>(CapStoreURL.URL+"/listProductByMostViewed")
  }

  public listOfBestSeller(): Observable<ViewProduct[]>
  {
    return this.http.get<ViewProduct[]>(CapStoreURL.URL+"/listProductByBestSeller")
  }

  public listProductInAsc(): Observable<Product[]>
  {
    return this.http.get<Product[]>(CapStoreURL.URL+"/listProductPriceInAsc")
  }
  public transaction(orderID:number, transaction:Transaction)
{
return this.http.post(CapStoreURL.URL+"/addTransaction/"+orderID,transaction,{responseType:'text'});
}

  public listProductInDesc(): Observable<Product[]>
  {
    return this.http.get<Product[]>(CapStoreURL.URL+"/listProductPriceInDesc")
  }
  public getShippingDetails(orderId:number)
{
  return this.http.get<OrderQuantityProduct[]>(CapStoreURL.URL+"/ship/"+orderId)
}

  public listPriceRange( low : number, high : number ) : Observable< Product[] >
{
  return this.http.get<Product[]>(CapStoreURL.URL+"/getProduct/price/"+low+"/"+high)
}

public getYourOrders(customerId : number)
  {
    return this.http.get<Order []>(CapStoreURL.URL+"/getYourOrder/95")
  }

  
  public returngoods(orderid:number,productid:number,quantity:number){
    return this.http.get<boolean>(CapStoreURL.URL+"/"+"return/"+orderid+"/"+productid+"/"+quantity);
  }

  public getCustomerDetails(customerId:number)
  {
    return this.http.get(CapStoreURL.URL+"/getCustomer/95")
  }
  
  public editProfile(customer:Customer)
  {
    return this.http.put(CapStoreURL.URL+"/editProfile",customer,{responseType:'text'})
  }

  
}
