export class CapStoreURL{
    static readonly url:string="http://localhost:9090/";
}