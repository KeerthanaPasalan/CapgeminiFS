import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Merchant } from '../merchant';


@Component({
  selector: 'app-merchantsignup',
  templateUrl: './merchantsignup.component.html',
  styleUrls: ['./merchantsignup.component.css']
})
export class MerchantsignupComponent implements OnInit {


  







  merchant:Merchant=new Merchant();
  errorMessage:string;
  status=false;
  password:string;
  
  constructor(private service:CapstoreService) { }

  ngOnInit() {
  }

  onSubmit(){
    this.service.merchantSignUp(this.merchant,this.password).subscribe(data=>{
      if(data["errorMessage"]!=undefined){
        this.errorMessage=data["errorMessage"];
        this.status=false
      }
      else{
        this.status=data;
      }

    });
  }

}

 


