export class Product{
    productId:number;
    productName:string;
    productPrice:number;
    productdescription:string;
    productBrand:string;
    productQuantity:number;
}