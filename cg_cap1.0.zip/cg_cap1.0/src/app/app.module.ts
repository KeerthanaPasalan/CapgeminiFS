import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/Forms';
import{HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { QuestionanswerComponent } from './questionanswer/questionanswer.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SortbyComponent } from './sortby/sortby.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { SearchComponent } from './search/search.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { ProfileComponent } from './profile/profile.component';
import { YourorderComponent } from './yourorder/yourorder.component';
import { LoginCustomerComponent } from './login-customer/login-customer.component';
import { ListallproductComponent } from './cart/listallproduct.component';
import { TransactionComponent } from './transaction/transaction.component';
import { ShippingComponent } from './shipping/shipping.component';


import { CustomerComponent } from './customer/customer.component';
import { MerchantComponent } from './merchant/merchant.component';
import { OrderComponent } from './order/order.component';
import { ProductComponent } from './product/product.component';
import { AnalysisComponent } from './analysis/analysis.component';
import { DisProductComponent } from './dis-product/dis-product.component';
import { DisCategoryComponent } from './dis-category/dis-category.component';
import { DisMerchantComponent } from './dis-merchant/dis-merchant.component';
import { GraphComponent } from './graph/graph.component';


//**************************************************************** */

import { AddproductComponent } from './addproduct/addproduct.component';


import { LoginmerchantComponent } from './loginmerchant/loginmerchant.component';
import { SearchbyorderComponent } from './searchbyorder/searchbyorder.component';
import { SearchbyproductComponent } from './searchbyproduct/searchbyproduct.component';

import { SignupmerchantComponent } from './signupmerchant/signupmerchant.component';
import { MerchantpageComponent } from './merchantpage/merchantpage.component';
import { ListproductsComponent } from './listproducts/listproducts.component';
import { AddcategoryComponent } from './addcategory/addcategory.component';
import { AdminComponent } from './admin/admin.component';
import { ListordersComponent } from './listorders/listorders.component';
import { LogoutmerchantComponent } from './logoutmerchant/logoutmerchant.component';
import { CustomersingnupComponent } from './customersingnup/customersingnup.component';
import { MerchantsignupComponent } from './merchantsignup/merchantsignup.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    QuestionanswerComponent,
    ErrorpageComponent,
    NavbarComponent,
    ProductlistComponent,
    HeaderComponent,
    FooterComponent,
    SortbyComponent,
    ProductpageComponent,
    SearchComponent,
    ReturngoodsComponent,
    ProfileComponent,
    YourorderComponent,
    LoginCustomerComponent,
    ListallproductComponent,
    TransactionComponent,
    ShippingComponent,
    CustomerComponent,
    MerchantComponent,
    OrderComponent,
    ProductComponent,
    AnalysisComponent,
    DisProductComponent,
    DisCategoryComponent,
    DisMerchantComponent,
    GraphComponent,
    AddproductComponent,
    LoginmerchantComponent,
    SearchbyorderComponent,
    SearchbyproductComponent,
    SignupmerchantComponent,
    MerchantpageComponent,
    ListproductsComponent,
    AddcategoryComponent,
    AdminComponent,
    ListordersComponent,
    LogoutmerchantComponent,
    CustomersingnupComponent,
    MerchantsignupComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
