import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogoutmerchantComponent } from './logoutmerchant.component';

describe('LogoutmerchantComponent', () => {
  let component: LogoutmerchantComponent;
  let fixture: ComponentFixture<LogoutmerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogoutmerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogoutmerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
