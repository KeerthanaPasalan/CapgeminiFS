import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
searchname:string
  constructor(private routes:Router) { }

  ngOnInit() {
  }
  onClick(){
    document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  }
  closeNav(){
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
  }
  test()
  {
  }
  productList()
  {
    this.routes.navigate([''])
    this.routes.navigate(['productlist/'+this.searchname])
  
  }
  logout()
  {
     if(sessionStorage.getItem("status").localeCompare("true")==0)
     {
       sessionStorage.setItem("status","false");  
     }
     this.routes.navigate(["login"]);
 alert("logout successfully")
  }
}