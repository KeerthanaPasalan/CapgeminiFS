export class Category{

    categoryId:number
    categoryName:string
    subCategory:string

}
	