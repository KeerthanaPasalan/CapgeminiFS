import { Component, OnInit } from '@angular/core';
import { CartQuantityProduct } from 'src/app/cart/listProduct';
import { CapStoreService } from 'src/app/cap-store.service';
import { Order } from '../order';
import { transformAll } from '@angular/compiler/src/render3/r3_ast';
import { Router } from '@angular/router';


@Component({
  selector: 'app-listallproduct',
  templateUrl: './listallproduct.component.html',
  styleUrls: ['./listallproduct.component.css']
})
export class ListallproductComponent implements OnInit {
  custId: number = parseInt(sessionStorage.getItem('custId'))
  list: CartQuantityProduct[]
  constructor(private service: CapStoreService, private router: Router) { }
  quantity: number = 0
  message: String
  prodId: number
  ordre: Order
  orderid: number
  totalamount: number = 0
  ngOnInit() {
    this.service.listAllProduct(this.custId).subscribe(data => {
    this.list = data
    console.log(this.list)
      if (this.list.length==undefined) {
        this.router.navigate(['error'])
      }
      else {
        for (let i = 0; i < this.list.length; i++) {
          this.totalamount = this.totalamount + this.list[i].product.productPrice
        }
      }
    })
    // this.list[0].product
    // this.quantity=sessionStorage.getItem()
  }
  onDesc(arr: CartQuantityProduct) {
  arr.quantity = arr.quantity - 1;

    this.service.updateProduct(arr.quantity, arr.product.productId, this.custId).subscribe(data => this.message = data)

  }
  onInc(arr: CartQuantityProduct) {
    arr.quantity = arr.quantity + 1;

    this.service.updateProduct(arr.quantity, arr.product.productId, this.custId).subscribe(data => this.message = data)
  }

  removeProduct(prodId: number) {
    console.log(prodId)
    this.service.deleteProduct(prodId, this.custId).subscribe(data => this.message = data)

  }

  placedOrder() {
    this.service.buynow(this.custId).subscribe(data => {
    this.orderid = <number>data
      this.router.navigate(['/transaction/' + this.orderid + '/' + this.totalamount])
    })

  }
  tran() { }

}
