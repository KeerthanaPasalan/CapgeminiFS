import { Component, OnInit } from '@angular/core';
import { Product } from '../addproduct/product';
import { MerchantService } from '../merchant.service';

@Component({
  selector: 'app-searchbyorder',
  templateUrl: './searchbyorder.component.html',
  styleUrls: ['./searchbyorder.component.css']
})
export class SearchbyorderComponent implements OnInit {

  orderId :number;

  products : Product[];

  errormessage : string;
  tblstatus : boolean=false;

  constructor(private service : MerchantService) { }

  ngOnInit() {
  }

  searchByOrder()
  {
   
     return this.service.searchByOrder(this.orderId).subscribe( data=>
      {
        if(data["errorMessage"]!=undefined)
        {
          
          this.errormessage=data["errorMessage"];
          alert(this.errormessage)
  
        } 
        else{
          this.tblstatus=true;
          this.products=<Product []>data;

        }
      }

     );
  }
}
