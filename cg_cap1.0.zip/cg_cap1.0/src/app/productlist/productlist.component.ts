import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { Router, ActivatedRoute } from '@angular/router';

import { Product } from './product';
import { ViewProduct } from '../viewProduct';
import { Image } from '../image';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  title: String = ""
  high: number
  low: number
  viewProduct: ViewProduct[]
  statuslh: boolean = false
  statusbm: boolean = false


  image1: string;
  products: Product[] = [];
  searchname: string
  image: string = '../assets/Desert.jpeg'
  imageLists :Image[];
  temp:string
  constructor(private service: CapStoreService, public routes: ActivatedRoute, private route: Router) { }

  ngOnInit() {
    this.searchname = this.routes.snapshot.paramMap.get('searchname')
    this.service.search(this.searchname).subscribe(data =>{ 
    this.products=data
  });
      // for (let i = 0; i < this.products.length; i++) {
        // this.imageLists=this.products[i].imageList
        // for(let j=0;j<this.imageLists.length;j++)
        // {
        //   console.log(this.imageLists.length)
        // }
      
  
    }
 

  productPage(prod_id: number) {
    this.route.navigate(['productpage/' + prod_id])
  }

  listProductInAsc() {
    this.title = "Low to High"
    this.statusbm = false
    this.statuslh = true
    this.service.listProductInAsc().subscribe(data => this.products = data)
  }
  listProductInDesc() {
    this.title = "High to Low"
    this.statusbm = false
    this.statuslh = true
    this.service.listProductInDesc().subscribe(data => this.products = data)
  }
  bestseller() {
    this.title = "Best Seller"
    this.statuslh = false
    this.statusbm = true
    this.service.listOfBestSeller().subscribe(data => this.viewProduct = data)
  }
  mostviewed() {
    this.title = "Most Viewed"
    this.statuslh = false
    this.statusbm = true
    this.service.listOfMostViewed().subscribe(data => this.viewProduct = data)
  }

  priceRange(low, high) {
    this.title = "Price Range"
    this.statuslh = true
    this.statusbm = false
    this.service.listPriceRange(low, high).subscribe(data => this.products = data)
  }


}
