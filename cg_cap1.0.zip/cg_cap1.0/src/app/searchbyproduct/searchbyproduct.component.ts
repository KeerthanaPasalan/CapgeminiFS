import { Component, OnInit } from '@angular/core';
import { Product } from '../addproduct/product';
import { MerchantService } from '../merchant.service';
import { Image } from '../addproduct/image';
import { Router } from '@angular/router';

@Component({
  selector: 'app-searchbyproduct',
  templateUrl: './searchbyproduct.component.html',
  styleUrls: ['./searchbyproduct.component.css']
})
export class SearchbyproductComponent implements OnInit {

  productId :number;

  tblstatus : boolean=false;

  products: Product[];
  nproduct: Product = new Product();
  product: Product = new Product();
  errormessage: string;
  message: string;
  stat : boolean;
  status: boolean = false;
  status1: boolean = false;
  image: Image = new Image();
  image1: string
  image2: string
  image3: string
  productid: number

  localUrl: any[];

  constructor(private service : MerchantService,private router : Router) { }

  ngOnInit() {
  }

  update(product: Product) {
    this.status = true;
    this.nproduct.productId = product.productId;
    this.nproduct.productQuantity = product.productQuantity;
    this.nproduct.productPrice = product.productPrice;
  }

  updateInventory() {
    return this.service.updateInventory(this.nproduct.productId, this.nproduct.productQuantity, this.nproduct.productPrice).subscribe(data => {
      if (data["errorMessage"] != undefined) {

        this.errormessage = data["errorMessage"];
        alert(this.errormessage)

      }
      else {
        this.message = <string>data;
        alert(this.message);
        this.status=false;
        this.router.navigateByUrl('/merchantPage', { skipLocationChange: true }).then(() => {
          this.router.navigate(['/listProducts']);
        });

      }
    }
    );
  }








  searchByProduct()
  {
     return this.service.searchByProduct(this.productId).subscribe( data=>
      {
        if(data["errorMessage"]!=undefined)
        {
          
          this.errormessage=data["errorMessage"];
          alert(this.errormessage)
  
        } 
        else{
          this.tblstatus=true;
          this.product=<Product>data;

        }
      }

     );
  }

  upload(productId: number) {
    this.status1 = true;
    this.product.productId = productId;
    this.image.productid = this.product.productId

  }



  showPreviewImage(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
      // this.image.imageLink=event.target.files[0];
      this.image1 = event.target.files[0].name;
      this.productid = this.product.productId;

      console.log(event.target.files[0].name)
    }
  }


  showPreviewImage3(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
      this.image3 = event.target.files[0].name;

      console.log(event.target.files[0].name)
    }
  }

  showPreviewImage2(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
      this.image2 = event.target.files[0].name;
      console.log(event.target.files[0].name)
    }
  }

  uploadImage() {
    this.service.uploadImage(this.productid, this.image1).subscribe(data => this.stat = data);
    this.service.uploadImage(this.productid, this.image2).subscribe(data => this.stat = data)

    this.service.uploadImage(this.productid, this.image3).subscribe(data => {if(data==true) alert("IMAGES UPLOADED SUCCESSFULLY")});


    this.status1 = false;
  }


}
