import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthgaurdCustomerService {

  constructor() { }

  canActivate() : boolean{
    if(sessionStorage.getItem("status").localeCompare("true")==0)
    {
      
       return true;
    }
    else{
      return false;
    }
    
  }
}
