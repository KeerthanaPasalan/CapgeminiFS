package com.capgemini.dao;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.bean.BankDetails;

public class BankDaoImplTest {
	 //positive response
    BankDaoImpl dao=new BankDaoImpl();
    @Test
    public void createAcc_1()
    {
        BankDetails bank=new BankDetails();
        bank.setBalance(5000);
        bank.setAccountNumber(12345);
        bank.setAccountType("savings");
        bank.setMobileNumber(1234567890);
        bank.setName("Keerthana");
       dao.insertBankDetails(bank);
        
        Assert.assertEquals(12345,12345);
        
    }
    //negative response
        @Test
        public void createAcc_2()
        {
            BankDetails bank=new BankDetails();
            bank.setBalance(5000);
            bank.setAccountNumber(12345);
            bank.setAccountType("savings");
            bank.setMobileNumber(1234567890);
            bank.setName("Keerthana");
            dao.insertBankDetails(bank);
            
            
            Assert.assertEquals(12345,12345);
            
        }
}                          

