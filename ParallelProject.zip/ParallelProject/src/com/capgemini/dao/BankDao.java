package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;

public interface BankDao {
	void insertBankDetails(BankDetails customer);
	//For creating Bank Account
	BankDetails retrieveBank(Long account1);
	//For Showing Balance
	BankDetails depositMoney(Long account2, Long depositAmount);
	//For depositing money in one account
	BankDetails withdrawMoney(Long accountNo3, Long withdrawAmount);
	//For withdrawing amount from given account
	BankDetails fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount);
	//Transferring amount to another account
	List<Transaction> printTransaction();
	//To Show all the transaction what we have done
}
