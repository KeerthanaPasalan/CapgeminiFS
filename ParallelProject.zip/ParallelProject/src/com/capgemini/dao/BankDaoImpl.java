package com.capgemini.dao;

import java.util.ArrayList;


import java.util.HashMap;
//import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import com.capgemini.bean.BankDetails;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.AccountNumberNotFoundException;

public class BankDaoImpl implements BankDao {
	//Using Map getting customer details
	Map<Long, BankDetails> customers = new HashMap<Long, BankDetails>();
	Map<Transaction, Long> tranInfo = new HashMap<Transaction, Long>();

	@Override
	public void insertBankDetails(BankDetails customer) {
		//Creating new bank account 
		 customers.put(customer.getAccountNumber(), customer);
	}

	@Override
	public BankDetails retrieveBank(Long account1) {
		//Retrieving balance from the given account
		BankDetails b1=customers.get(account1);
		
		if(b1 == null )
		{
			throw new AccountNumberNotFoundException("Enter Valid Account Number");
		}
		return b1;
	}

	@Override
	public BankDetails depositMoney(Long account2, Long depositAmount) {
		//Depositing amount for the given account 
		BankDetails b3 = customers.get(account2);
		if(b3 == null )
		{
			throw new AccountNumberNotFoundException("Enter Valid Account Number");
		}
		Long bal2 = b3.getBalance();
		Long bal3 = bal2 + depositAmount;
		b3.setBalance(bal3);

		Transaction bankTran = new Transaction();
		bankTran.setTransactionType("Deposit");
		bankTran.setTransctionId(12345);
		bankTran.setToAccount(account2);
		bankTran.setOldBalance(bal2);
		bankTran.setNewBalance(bal3);
		tranInfo.put(bankTran, account2);
		return b3;
	}

	@Override
	public BankDetails withdrawMoney(Long accountNo3, Long withdrawAmount) {
		//withdrawing amount for the given account
		BankDetails b4 = customers.get(accountNo3);
		if(b4 == null )
		{
			throw new  AccountNumberNotFoundException("Enter Valid Account Number");
			//InputMismatchException("");
		}
		long bal5 = b4.getBalance();
		long bal6 = bal5 - withdrawAmount;
		b4.setBalance(bal6);

		Transaction bankTran = new Transaction();
		bankTran.setTransctionId(12346);
		bankTran.setFromAccount(accountNo3);
		bankTran.setOldBalance(bal5);
		bankTran.setNewBalance(bal6);
		bankTran.setTransactionType("Withdraw");

		tranInfo.put(bankTran, accountNo3);

		return b4;
	}

	@Override
	public BankDetails fundTransfer(Long accountNo1, Long accountNo2, Long transferAmount) {
		//Transferring amount from one account to another account
		BankDetails acc1 = customers.get(accountNo1);
		if(acc1 == null )
		{
			throw new AccountNumberNotFoundException("Enter Valid Account Number");
		}
		BankDetails acc2 = customers.get(accountNo2);
		if(acc2 == null )
		{
			throw new AccountNumberNotFoundException("Enter Valid Account Number");
		}
		Long oldBal1 = acc1.getBalance();
		Long oldBal2 = acc2.getBalance();
		if(oldBal1>=transferAmount)
		{
		
		Long newBal1 = oldBal1 - transferAmount;
		Long newBal2 = oldBal2 + transferAmount;
		acc1.setBalance(newBal1);
		acc2.setBalance(newBal2);

		Transaction bankTran = new Transaction();
		bankTran.setTransctionId(12345678);
		bankTran.setFromAccount(accountNo1);
		bankTran.setToAccount(accountNo2);
		bankTran.setOldBalance(oldBal1);
		bankTran.setNewBalance(newBal1);
		bankTran.setTransactionType("Transfer");

		tranInfo.put(bankTran, accountNo1);
		System.out.println("Amount transfered Successfully");
		}
		else
		{
			System.out.println("Insuffiecient Balance");
		}
		return acc1;
	}

	@Override
	public List<Transaction> printTransaction() {
		//To displaying all transaction what we use
		System.out.println("**" + tranInfo.size() + "**");
		List<Transaction> list = new ArrayList<Transaction>(tranInfo.keySet());
		return list;

	}

}

